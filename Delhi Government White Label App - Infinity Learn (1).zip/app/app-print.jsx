// app-print.jsx — renders every screen stacked, one per page, at full content height
function PrintScreen({ id, label, Comp, n }){
  const ctx = { screen:id, go:()=>{}, mode:'full', lang:'bi', setLang:()=>{}, play:'balanced' };
  return (
    <div className="page">
      <div className="page-label"><span className="pl-n">{n}</span> {label}</div>
      <AppCtx.Provider value={ctx}>
        <div className="stage-print" style={{ '--accent':'#1A73E9', '--accent-ink':'#0f4ea3', '--accent-soft':'#eaf2fe', '--zoom':1 }}>
          <div className="phone print-phone">
            <Comp/>
          </div>
        </div>
      </AppCtx.Provider>
    </div>
  );
}

function PrintApp(){
  const screens = [
    ['splash','Launch / Splash', SplashScreen],
    ['login','Login', LoginScreen],
    ['home','Dashboard', DashboardScreen],
    ['tests','Weekly Assessments', TestsScreen],
    ['assessIntro','Assessment — Intro', AssessIntroScreen],
    ['assessQ','Assessment — Question', AssessQScreen],
    ['results','Results / Test Analysis', ResultsScreen],
    ['mentor','AINA — AI Mentor', MentorScreen],
    ['progress','Progress & Analytics', ProgressScreen],
    ['profile','Profile', ProfileScreen],
  ];
  return (
    <React.Fragment>
      {screens.map(([id,label,Comp],i)=>(
        <PrintScreen key={id} id={id} label={label} Comp={Comp} n={String(i+1).padStart(2,'0')}/>
      ))}
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<PrintApp/>);

// ---- auto-print once fonts + images are ready ----
function whenImagesReady(cb){
  const imgs = [...document.images];
  let pending = imgs.filter(i=>!i.complete).length;
  if(!pending) return cb();
  imgs.forEach(i=>{
    if(i.complete) return;
    const done = ()=>{ if(--pending<=0) cb(); };
    i.addEventListener('load', done);
    i.addEventListener('error', done);
  });
}
(document.fonts ? document.fonts.ready : Promise.resolve()).then(()=>{
  // allow React to mount + Ring/Bar state timeouts (~60ms) to settle
  setTimeout(()=> whenImagesReady(()=> setTimeout(()=> window.print(), 600)), 400);
});
