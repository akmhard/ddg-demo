// app.jsx — root: router + context + tweaks + phone frame
const { useState:useS, useEffect:useE } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "version": "full",
  "language": "en",
  "accent": ["#1A73E9", "#0f4ea3", "#eaf2fe"],
  "fontSize": "normal",
  "playfulness": "balanced",
  "motion": true
}/*EDITMODE-END*/;

const ACCENTS = [
  ["#1A73E9","#0f4ea3","#eaf2fe"],  // UX4G blue
  ["#1E9E54","#14723b","#e3f5ea"],  // Delhi green
  ["#E8862B","#b5651d","#fdeede"],  // saffron
  ["#7d3fb0","#5a2c80","#f1eafa"],  // violet
  ["#0E8E8E","#0a6a6a","#e0f3f3"],  // teal
];
const ZOOM = { small:0.92, normal:1, large:1.12 };

// ---------- in-page Preferences sheet (mirror of the host Tweaks) ----------
function PrefsSheet({ t, setTweak, onClose }){
  const essential = t.version==='essential';
  const curLang = essential ? 'en' : t.language;
  const accentEq = (a)=> Array.isArray(t.accent) && t.accent[0]===a[0];
  const Seg = ({ value, options, onChange, disabled })=>(
    <div className="seg" style={{ opacity:disabled?.5:1, pointerEvents:disabled?'none':'auto' }}>
      {options.map(o=>(
        <button key={o.value} className={value===o.value?'on':''} onClick={()=>onChange(o.value)} style={{ flexDirection:'row' }}>{o.label}</button>
      ))}
    </div>
  );
  return (
    <div style={{ position:'absolute', inset:0, zIndex:80, display:'flex', alignItems:'flex-end' }}>
      <div onClick={onClose} style={{ position:'absolute', inset:0, background:'rgba(15,20,30,.45)' }}/>
      <div className="scr-anim" style={{ position:'relative', width:'100%', background:'#fff', borderRadius:'22px 22px 36px 36px', padding:'14px 20px 26px', maxHeight:'82%', overflowY:'auto' }}>
        <div style={{ width:40, height:4, borderRadius:3, background:'var(--line)', margin:'0 auto 14px' }}/>
        <div className="row" style={{ justifyContent:'space-between', marginBottom:4 }}>
          <div className="row" style={{ gap:9 }}>
            <span style={{ width:30, height:30, borderRadius:9, background:'var(--accent-soft)', color:'var(--accent)', display:'flex', alignItems:'center', justifyContent:'center' }}><i className="fa-solid fa-sliders"></i></span>
            <div>
              <Ti hi="प्राथमिकताएँ" en="Preferences" className="" style={{ fontWeight:700, fontSize:16 }}/>
              <div className="tiny"><Ti hi="भाषा, रंग व संस्करण" en="Language, colour & version"/></div>
            </div>
          </div>
          <button onClick={onClose} style={{ width:32, height:32, borderRadius:'50%', border:'1px solid var(--line)', background:'#fff', color:'var(--ink2)', cursor:'pointer' }}><i className="fa-solid fa-xmark"></i></button>
        </div>

        {/* Version */}
        <div style={{ marginTop:18 }}>
          <div className="row" style={{ justifyContent:'space-between', marginBottom:8 }}>
            <label style={{ fontSize:11, fontWeight:700, letterSpacing:'.04em', textTransform:'uppercase', color:'var(--ink3)' }}><Ti hi="ऐप संस्करण" en="App version"/></label>
            <span className="tiny">{essential? <Ti hi="सरल" en="Lite"/> : <Ti hi="पूर्ण" en="Full"/>}</span>
          </div>
          <Seg value={t.version} onChange={v=>setTweak('version',v)}
            options={[{value:'full',label: t.language==='en'?'Full':'पूर्ण'},{value:'essential',label: t.language==='en'?'Essential':'सरल'}]}/>
          <div className="tiny" style={{ marginTop:7, lineHeight:1.5 }}>
            {essential
              ? <Ti hi="सरल: स्ट्रीक, एक्सपी, बैज व प्रगति हटा दी गई — केवल मूल कार्य।" en="Essential: streaks, XP, badges & analytics removed — core only."/>
              : <Ti hi="पूर्ण: स्ट्रीक, एक्सपी, बैज व विस्तृत प्रगति सहित।" en="Full: with streaks, XP, badges & detailed analytics."/>}
          </div>
        </div>

        {/* Language */}
        <div style={{ marginTop:18 }}>
          <label style={{ fontSize:11, fontWeight:700, letterSpacing:'.04em', textTransform:'uppercase', color:'var(--ink3)' }}><Ti hi="भाषा" en="Language"/></label>
          <div style={{ marginTop:8 }}>
            <Seg value={curLang} disabled={essential} onChange={v=>setTweak('language',v)}
              options={[{value:'hi',label:'हिंदी'},{value:'en',label:'English'},{value:'bi',label:'दोनों / Both'}]}/>
          </div>
          {essential && <div className="tiny" style={{ marginTop:7 }}><i className="fa-solid fa-lock" style={{fontSize:9}}></i> <Ti hi="सरल संस्करण में केवल अंग्रेज़ी" en="English only in the Essential version"/></div>}
        </div>

        {/* Accent colour */}
        <div style={{ marginTop:18 }}>
          <label style={{ fontSize:11, fontWeight:700, letterSpacing:'.04em', textTransform:'uppercase', color:'var(--ink3)' }}><Ti hi="थीम रंग" en="Accent colour"/></label>
          <div className="row" style={{ gap:13, marginTop:11 }}>
            {ACCENTS.map((a,i)=>(
              <button key={i} onClick={()=>setTweak('accent',a)} style={{ width:38, height:38, borderRadius:'50%', background:a[0], border:'none', cursor:'pointer', position:'relative', boxShadow: accentEq(a)?`0 0 0 3px #fff, 0 0 0 5px ${a[0]}`:'0 1px 3px rgba(0,0,0,.2)' }}>
                {accentEq(a) && <i className="fa-solid fa-check" style={{ color:'#fff', fontSize:13 }}></i>}
              </button>
            ))}
          </div>
        </div>

        <button className="btn btn-primary" style={{ marginTop:24 }} onClick={onClose}><Ti hi="हो गया" en="Done"/></button>
      </div>
    </div>
  );
}

function Root(){
  const [t,setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [screen,setScreen] = useS(()=>{
    const h = (location.hash||'').replace('#','');
    return h || 'splash';
  });
  const [scale,setScale] = useS(1);
  const [showPrefs,setShowPrefs] = useS(false);
  const bodyScrollReset = ()=>{ requestAnimationFrame(()=>{ const b=document.querySelector('.body'); if(b) b.scrollTop=0; }); };
  const go = (s)=>{ setScreen(s); bodyScrollReset(); };
  window.__appGo = go;   // exposed for PPTX export navigation

  useE(()=>{
    const fit = ()=>{
      const ph = document.querySelector('.phone'); if(!ph) return;
      const margin = 32;
      const s = Math.min(
        (window.innerWidth - margin) / ph.offsetWidth,
        (window.innerHeight - margin) / ph.offsetHeight,
        1
      );
      setScale(s);
    };
    fit();
    window.addEventListener('resize', fit);
    return ()=>window.removeEventListener('resize', fit);
  },[]);

  const ctx = {
    screen, go,
    mode: t.version,                                   // 'full' | 'essential'
    lang: t.version==='essential' ? 'en' : t.language, // essential = English only
    setLang: (v)=>setTweak('language', v),
    play: t.version==='essential' ? 'official' : t.playfulness,
    openPrefs: ()=>setShowPrefs(true),
  };

  const accent = Array.isArray(t.accent) ? t.accent : ACCENTS[0];
  const wrapStyle = {
    '--accent': accent[0], '--accent-ink': accent[1], '--accent-soft': accent[2],
    '--zoom': ZOOM[t.fontSize] || 1,
  };

  const Screen = {
    splash: SplashScreen, login: LoginScreen, home: DashboardScreen, tests: TestsScreen,
    assessIntro: AssessIntroScreen, assessQ: AssessQScreen, results: ResultsScreen,
    mentor: MentorScreen, progress: ProgressScreen, profile: ProfileScreen,
    doubts: DoubtsScreen,
  }[screen] || DashboardScreen;

  return (
    <AppCtx.Provider value={ctx}>
      <div className={'stage'+(t.motion?'':' no-anim')} style={wrapStyle}>
        <div className="phone-scale" style={{ transform:`scale(${scale})` }}>
          <div className="phone">
            <div className="dyn"></div>
            <div key={screen} className="scr-anim" style={{ width:'100%', height:'100%' }}>
              <Screen/>
            </div>
            {showPrefs && <PrefsSheet t={t} setTweak={setTweak} onClose={()=>setShowPrefs(false)}/>}
          </div>
        </div>
      </div>

      <TweaksPanel title="Tweaks">
        <TweakSection label="App version"/>
        <TweakRadio label="Version" value={t.version}
          options={[{value:'full',label:'Full'},{value:'essential',label:'Essential'}]}
          onChange={v=>setTweak('version',v)}/>

        <TweakSection label="Language & Reading"/>
        <TweakRadio label="Language" value={t.version==='essential'?'en':t.language}
          options={[{value:'hi',label:'हिंदी'},{value:'en',label:'English'},{value:'bi',label:'Both'}]}
          onChange={v=>setTweak('language',v)}/>
        <TweakRadio label="Text size" value={t.fontSize}
          options={[{value:'small',label:'A−'},{value:'normal',label:'A'},{value:'large',label:'A+'}]}
          onChange={v=>setTweak('fontSize',v)}/>

        <TweakSection label="Theme"/>
        <TweakColor label="Accent colour" value={t.accent} options={ACCENTS}
          onChange={v=>setTweak('accent',v)}/>

        <TweakSection label="Feel"/>
        <TweakRadio label="Playfulness" value={t.playfulness}
          options={[{value:'official',label:'Official'},{value:'balanced',label:'Balanced'},{value:'playful',label:'Playful'}]}
          onChange={v=>setTweak('playfulness',v)}/>
        <TweakToggle label="Animations" value={t.motion} onChange={v=>setTweak('motion',v)}/>
      </TweaksPanel>
    </AppCtx.Provider>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<Root/>);
