// context.jsx — shared app context across babel scripts
const AppCtx = React.createContext({});
function useApp(){ return React.useContext(AppCtx); }
Object.assign(window, { AppCtx, useApp });
