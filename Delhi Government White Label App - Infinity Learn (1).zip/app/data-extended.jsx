// data-extended.jsx — content for the new states & flows
// (multiple assessments due, cumulative report, doubts, extended AINA mentor)

// ---------- Multiple assessments due the SAME day ----------
const DUE_TODAY = [
  { id:'math', week:14, subj:{hi:'गणित',en:'Mathematics'}, topic:{hi:'पूर्णांक और आँकड़ों का प्रबंधन',en:'Integers & Data Handling'},
    q:6, mins:20, xp:50, due:{hi:'आज शाम 5 बजे तक',en:'Due today · 5:00 PM'}, soon:true,
    grad:'linear-gradient(145deg,#7d3fb0,#a066cc 58%,#bd86e0)', accent:'#7d3fb0', icon:'fa-square-root-variable' },
  { id:'sci', week:14, subj:{hi:'विज्ञान',en:'Science'}, topic:{hi:'अम्ल, क्षार एवं लवण',en:'Acids, Bases & Salts'},
    q:5, mins:15, xp:40, due:{hi:'आज रात 8 बजे तक',en:'Due today · 8:00 PM'},
    grad:'linear-gradient(145deg,#137a43,#1E9E54 58%,#46c47e)', accent:'#137a43', icon:'fa-flask' },
  { id:'soc', week:14, subj:{hi:'सामाजिक विज्ञान',en:'Social Science'}, topic:{hi:'हमारे पर्यावरण — II',en:'Our Environment — II'},
    q:6, mins:20, xp:50, due:{hi:'आज रात 9 बजे तक',en:'Due today · 9:00 PM'},
    grad:'linear-gradient(145deg,#b5651d,#E8862B 58%,#f0a45a)', accent:'#b5651d', icon:'fa-earth-asia' },
  { id:'eng', week:14, subj:{hi:'अंग्रेज़ी',en:'English'}, topic:{hi:'अपठित गद्यांश व व्याकरण',en:'Comprehension & Grammar'},
    q:5, mins:15, xp:40, due:{hi:'कल सुबह तक',en:'Due tomorrow'}, tomorrow:true,
    grad:'linear-gradient(145deg,#7b3aa6,#9A52C7 58%,#c084e0)', accent:'#7b3aa6', icon:'fa-feather-pointed' },
];

// ---------- Cumulative / meta report ----------
const REPORT = {
  terms: [
    { id:'t2', hi:'पद 2 · साप्ताहिक मूल्यांकन', en:'Term 2 · Weekly Assessments' },
    { id:'t1', hi:'पद 1 · साप्ताहिक मूल्यांकन', en:'Term 1 · Weekly Assessments' },
    { id:'half', hi:'अर्धवार्षिक परीक्षा', en:'Half-Yearly Exam' },
  ],
  avg:  { score:8.4, max:12, pct:70, classAvg:7.1 },
  accuracy: { pct:79, classPct:74 },
  attempted: { done:11, total:14 },
  rank: { pos:6, of:38, delta:+3 },
};

// Recent tests carousel (weekly assessments)
const RECENT_TESTS = [
  { name:{hi:'पूर्णांक व आँकड़े',en:'Integers & Data'}, date:'02 Jun 2026', tag:{hi:'साप्ताहिक',en:'Weekly'},
    score:8, max:12, pct:67, color:'var(--subj-math)',
    stats:[ {l:{hi:'सटीकता',en:'Accuracy'},v:'67%'}, {l:{hi:'कक्षा रैंक',en:'Class rank'},v:'6/38'}, {l:{hi:'समय',en:'Time'},v:'14m'}, {l:{hi:'दक्षताएँ',en:'Skills'},v:'4/5'} ] },
  { name:{hi:'पादप में पोषण',en:'Nutrition in Plants'}, date:'29 May 2026', tag:{hi:'साप्ताहिक',en:'Weekly'},
    score:9, max:10, pct:90, color:'var(--subj-sci)',
    stats:[ {l:{hi:'सटीकता',en:'Accuracy'},v:'90%'}, {l:{hi:'कक्षा रैंक',en:'Class rank'},v:'2/38'}, {l:{hi:'समय',en:'Time'},v:'12m'}, {l:{hi:'दक्षताएँ',en:'Skills'},v:'5/5'} ] },
  { name:{hi:'भिन्न व दशमलव',en:'Fractions & Decimals'}, date:'26 May 2026', tag:{hi:'साप्ताहिक',en:'Weekly'},
    score:10, max:12, pct:83, color:'var(--subj-math)',
    stats:[ {l:{hi:'सटीकता',en:'Accuracy'},v:'83%'}, {l:{hi:'कक्षा रैंक',en:'Class rank'},v:'4/38'}, {l:{hi:'समय',en:'Time'},v:'16m'}, {l:{hi:'दक्षताएँ',en:'Skills'},v:'4/5'} ] },
  { name:{hi:'हमारे पर्यावरण',en:'Our Environment'}, date:'22 May 2026', tag:{hi:'साप्ताहिक',en:'Weekly'},
    score:7, max:12, pct:58, color:'var(--subj-soc)',
    stats:[ {l:{hi:'सटीकता',en:'Accuracy'},v:'58%'}, {l:{hi:'कक्षा रैंक',en:'Class rank'},v:'15/38'}, {l:{hi:'समय',en:'Time'},v:'18m'}, {l:{hi:'दक्षताएँ',en:'Skills'},v:'3/6'} ] },
];

// Subject-wise performance — colour-coded accuracy bands, expand for chapter grid
// band: excellent (>=80) / good (60-79) / average (40-59) / weak (<40) / untaught
const SUBJECT_PERF = [
  { id:'math', s:{hi:'गणित',en:'Mathematics'}, qs:128, acc:78, correct:84, incorrect:24, unatt:20,
    chapters:[
      { n:{hi:'पूर्णांक',en:'Integers'}, acc:72, correct:13, att:18 },
      { n:{hi:'आँकड़ों का प्रबंधन',en:'Data Handling'}, acc:90, correct:18, att:20 },
      { n:{hi:'भिन्न व दशमलव',en:'Fractions & Decimals'}, acc:83, correct:15, att:18 },
      { n:{hi:'सरल समीकरण',en:'Simple Equations'}, acc:64, correct:9, att:14 },
      { n:{hi:'रेखाएँ व कोण',en:'Lines & Angles'}, acc:55, correct:6, att:11 },
      { n:{hi:'परिमेय संख्याएँ',en:'Rational Numbers'}, acc:38, correct:3, att:8 },
      { n:{hi:'त्रिभुज',en:'The Triangle'}, acc:48, correct:5, att:10 },
      { n:{hi:'राशियों की तुलना',en:'Comparing Quantities'}, acc:null, correct:0, att:0 },
    ] },
  { id:'sci', s:{hi:'विज्ञान',en:'Science'}, qs:96, acc:84, correct:68, incorrect:16, unatt:12,
    chapters:[
      { n:{hi:'पादप में पोषण',en:'Nutrition in Plants'}, acc:92, correct:18, att:20 },
      { n:{hi:'जंतुओं में पोषण',en:'Nutrition in Animals'}, acc:81, correct:13, att:16 },
      { n:{hi:'ऊष्मा',en:'Heat'}, acc:76, correct:10, att:13 },
      { n:{hi:'अम्ल, क्षार व लवण',en:'Acids, Bases & Salts'}, acc:58, correct:7, att:12 },
      { n:{hi:'भौतिक व रासायनिक परिवर्तन',en:'Physical & Chemical Changes'}, acc:88, correct:14, att:16 },
      { n:{hi:'मौसम व जलवायु',en:'Weather & Climate'}, acc:null, correct:0, att:0 },
    ] },
  { id:'soc', s:{hi:'सामाजिक विज्ञान',en:'Social Science'}, qs:88, acc:69, correct:50, incorrect:24, unatt:14,
    chapters:[
      { n:{hi:'पर्यावरण',en:'Environment'}, acc:58, correct:7, att:12 },
      { n:{hi:'हमारी पृथ्वी के अंदर',en:'Inside Our Earth'}, acc:72, correct:10, att:14 },
      { n:{hi:'वायु',en:'Air'}, acc:64, correct:9, att:14 },
      { n:{hi:'समानता',en:'On Equality'}, acc:81, correct:13, att:16 },
      { n:{hi:'जल',en:'Water'}, acc:42, correct:5, att:12 },
      { n:{hi:'बाज़ार',en:'Markets Around Us'}, acc:null, correct:0, att:0 },
    ] },
  { id:'eng', s:{hi:'अंग्रेज़ी',en:'English'}, qs:72, acc:81, correct:52, incorrect:12, unatt:8,
    chapters:[
      { n:{hi:'अपठित गद्यांश',en:'Comprehension'}, acc:85, correct:17, att:20 },
      { n:{hi:'व्याकरण — काल',en:'Grammar — Tenses'}, acc:78, correct:11, att:14 },
      { n:{hi:'शब्दावली',en:'Vocabulary'}, acc:88, correct:14, att:16 },
      { n:{hi:'लेखन कौशल',en:'Writing Skills'}, acc:62, correct:8, att:13 },
    ] },
  { id:'hin', s:{hi:'हिंदी',en:'Hindi'}, qs:80, acc:88, correct:62, incorrect:8, unatt:10,
    chapters:[
      { n:{hi:'अपठित बोध',en:'Comprehension'}, acc:92, correct:18, att:20 },
      { n:{hi:'व्याकरण — संधि',en:'Grammar — Sandhi'}, acc:84, correct:14, att:17 },
      { n:{hi:'रचना — पत्र लेखन',en:'Letter Writing'}, acc:90, correct:16, att:18 },
      { n:{hi:'पद्य',en:'Poetry'}, acc:86, correct:13, att:15 },
    ] },
];

// ---------- Doubts flow (AINA-powered) ----------
const DOUBT_SUBJECTS = [
  { id:'math', hi:'गणित', en:'Mathematics' },
  { id:'sci',  hi:'विज्ञान', en:'Science' },
  { id:'soc',  hi:'सामाजिक विज्ञान', en:'Social Science' },
  { id:'eng',  hi:'अंग्रेज़ी', en:'English' },
  { id:'hin',  hi:'हिंदी', en:'Hindi' },
];

// A worked doubt — Class 7 integers (matches the assessment context)
const DOUBT_SAMPLE = {
  subject:{ hi:'गणित', en:'Mathematics' },
  q:{ hi:'एक पनडुब्बी समुद्र-तल से −350 मी की गहराई पर है। वह 125 मी और नीचे जाती है, फिर 90 मी ऊपर आती है। उसकी अंतिम गहराई क्या होगी?',
      en:'A submarine is at a depth of −350 m below sea level. It descends 125 m further, then rises 90 m. What is its final depth?' },
  hint:{ hi:'नीचे जाना = घटाना (−), ऊपर आना = जोड़ना (+)। तीनों परिवर्तनों को क्रम से जोड़ें।',
         en:'Going down = subtract (−), coming up = add (+). Combine the three changes in order.' },
  steps:[
    { n:1, t:{ hi:'आरंभिक गहराई लिखिए: −350 मी (तल से नीचे, इसलिए ऋणात्मक)।', en:'Start with the initial depth: −350 m (below sea level, so negative).' } },
    { n:2, t:{ hi:'125 मी और नीचे जाना → घटाइए: −350 − 125 = −475 मी।', en:'Descends 125 m more → subtract: −350 − 125 = −475 m.' } },
    { n:3, t:{ hi:'90 मी ऊपर आना → जोड़िए: −475 + 90 = −385 मी।', en:'Rises 90 m → add: −475 + 90 = −385 m.' } },
  ],
  answer:{ hi:'−385 मी', en:'−385 m' },
  solution:{ hi:'पनडुब्बी की अंतिम गहराई समुद्र-तल से −385 मी है, अर्थात् वह आरंभिक स्थिति से 35 मी अधिक गहराई पर है।',
             en:'The submarine\u2019s final depth is −385 m below sea level — that is 35 m deeper than where it started.' },
  comp:'C-7.3',
};

// ---------- Guided study plan (used in AINA mentor) ----------
const STUDY_PLAN = {
  title:{ hi:'रविवार तक की 3-दिन योजना', en:'Your 3-day plan to Sunday' },
  sub:{ hi:'सप्ताह 14 की कमियों के आधार पर — रोज़ ~25 मिनट', en:'Based on your Week 14 gaps — about 25 min a day' },
  days:[
    { day:{hi:'आज',en:'Today'}, mins:25, tasks:[
      { t:{hi:'संख्या-रेखा पर पूर्णांकों का क्रम',en:'Order integers on a number line'}, mins:10, done:true },
      { t:{hi:'5 तुलना-प्रश्नों का अभ्यास',en:'Practise 5 comparison questions'}, mins:10, done:true },
      { t:{hi:'आइना के साथ 1 संदेह हल करें',en:'Clear 1 doubt with AINA'}, mins:5, done:false },
    ] },
    { day:{hi:'कल',en:'Tomorrow'}, mins:25, tasks:[
      { t:{hi:'ऋण × ऋण = धन — पैटर्न विधि',en:'Why neg × neg = positive (pattern method)'}, mins:8, done:false },
      { t:{hi:'अपना तर्क शब्दों में लिखने का अभ्यास',en:'Practise explaining reasoning in words'}, mins:12, done:false },
      { t:{hi:'2 मिश्रित प्रश्न',en:'2 mixed questions'}, mins:5, done:false },
    ] },
    { day:{hi:'रविवार',en:'Sunday'}, mins:20, tasks:[
      { t:{hi:'पूरा अध्याय दोहराएँ',en:'Quick revision of the full chapter'}, mins:10, done:false },
      { t:{hi:'अभ्यास टेस्ट दें',en:'Take a practice test'}, mins:10, done:false },
    ] },
  ],
};

// ---------- Practice-a-similar-question loop (used in AINA mentor) ----------
const PRACTICE_Q = {
  comp:'C-7.4',
  q:{ hi:'इनमें सबसे छोटा पूर्णांक कौन-सा है?  (−2, −9, 1, −5)', en:'Which of these is the smallest integer?  (−2, −9, 1, −5)' },
  opts:[ {k:'A',hi:'−2',en:'−2'}, {k:'B',hi:'−9',en:'−9'}, {k:'C',hi:'1',en:'1'}, {k:'D',hi:'−5',en:'−5'} ],
  correct:1,
  explainOk:{ hi:'बिलकुल सही! −9 संख्या-रेखा पर सबसे बाईं ओर है, इसलिए सबसे छोटा।', en:'Exactly right! −9 is furthest left on the number line, so it is the smallest.' },
  explainNo:{ hi:'ध्यान दो — संख्या जितनी “बड़ी” ऋणात्मक दिखे, असल में उतनी ही छोटी होती है। −9 सबसे छोटा है।', en:'Remember — the “bigger-looking” negative is actually smaller. −9 is the smallest.' },
};

// ---------- Trends over time (for the report) ----------
const WK_LABELS = ['W9','W10','W11','W12','W13','W14'];
const TRENDS = {
  // switchable single-metric lines
  metrics:[
    { id:'acc',   label:{hi:'सटीकता',en:'Accuracy'}, unit:'%', color:'#1E9E54', data:[58,64,61,72,70,79], classData:[68,70,69,73,72,74], good:'up' },
    { id:'score', label:{hi:'स्कोर',en:'Score'},     unit:'/12', color:'#2D6BE3', data:[6.8,7.4,7.1,8.2,8.0,8.4], classData:[7.0,7.0,7.1,7.2,7.1,7.1], good:'up', max:12 },
    { id:'rank',  label:{hi:'कक्षा रैंक',en:'Class rank'}, unit:'', color:'#7d3fb0', data:[14,12,13,9,8,6], good:'down', invert:true, of:38 },
    { id:'speed', label:{hi:'गति (सेकंड/प्रश्न)',en:'Speed (sec/Q)'}, unit:'s', color:'#E8862B', data:[95,88,90,78,74,68], good:'down', invert:true },
  ],
  // subject mastery, multi-line
  subjectLines:[
    { id:'math', label:{hi:'गणित',en:'Maths'},   color:'#2D6BE3', data:[55,60,58,70,68,78] },
    { id:'sci',  label:{hi:'विज्ञान',en:'Sci'},   color:'#1E9E54', data:[62,66,70,72,80,84] },
    { id:'soc',  label:{hi:'सा.वि.',en:'SST'},    color:'#E8862B', data:[50,55,52,60,64,69] },
    { id:'hin',  label:{hi:'हिंदी',en:'Hindi'},   color:'#7d3fb0', data:[80,82,84,85,86,88] },
  ],
};

// AINA insights derived from the trends
const TREND_INSIGHTS = [
  { tone:'good', icon:'fa-arrow-trend-up',
    title:{hi:'लगातार सुधार',en:'Steady improvement'},
    body:{hi:'पिछले 6 सप्ताह में तुम्हारी सटीकता 58% से 79% तक पहुँची — हर पखवाड़े लगभग +7%। यही रफ़्तार रखो!',
          en:'Your accuracy climbed from 58% to 79% over 6 weeks — about +7% a fortnight. Keep that pace!'} },
  { tone:'good', icon:'fa-gauge-high',
    title:{hi:'तेज़ और सटीक',en:'Faster and accurate'},
    body:{hi:'अब तुम हर प्रश्न पर 68 सेकंड लेती हो (पहले 95)। गति बढ़ी पर सटीकता गिरी नहीं — यह बेहतरीन है।',
          en:'You now spend 68s per question (was 95s). Faster, yet accuracy held — that\u2019s excellent control.'} },
  { tone:'good', icon:'fa-ranking-star',
    title:{hi:'रैंक में उछाल',en:'Climbing the ranks'},
    body:{hi:'कक्षा रैंक 14 से 6 पर आ गई। तुम अब कक्षा के शीर्ष 16% में हो।',
          en:'Class rank moved from 14th to 6th — you\u2019re now in the top 16% of the class.'} },
  { tone:'watch', icon:'fa-droplet',
    title:{hi:'ध्यान दें: सामाजिक विज्ञान',en:'Watch: Social Science'},
    body:{hi:'सा. विज्ञान की निपुणता बाकी विषयों से धीमी बढ़ रही है (अभी 69%)। “जल” अध्याय सबसे कमज़ोर है।',
          en:'Social Science mastery is rising slowest (69% now). The “Water” chapter is the weakest link.'} },
  { tone:'watch', icon:'fa-wave-square',
    title:{hi:'सप्ताह 11 में गिरावट',en:'A dip in Week 11'},
    body:{hi:'सप्ताह 11 में स्कोर थोड़ा गिरा था — वहाँ “परिमेय संख्याएँ” आई थीं। उसे दोबारा देखना अच्छा रहेगा।',
          en:'Week 11 saw a small dip — that was “Rational Numbers”. A quick revisit would help.'} },
];

Object.assign(window, { DUE_TODAY, REPORT, RECENT_TESTS, SUBJECT_PERF, DOUBT_SUBJECTS, DOUBT_SAMPLE, STUDY_PLAN, PRACTICE_Q, TRENDS, TREND_INSIGHTS, WK_LABELS });
