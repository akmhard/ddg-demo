// data.jsx — Shiksha Saarthi demo content (Class 7 · Mathematics)
const STUDENT = {
  name: { hi:'नीतू कुमारी', en:'Neetu Kumari' },
  first:{ hi:'नीतू', en:'Neetu' },
  cls:  { hi:'कक्षा 7-ब', en:'Class 7-B' },
  school:{ hi:'सर्वोदय कन्या विद्यालय, कालकाजी', en:'Sarvodaya Kanya Vidyalaya, Kalkaji' },
  roll: '23',
  streak: 12,
  xp: 1840,
  coins: 320,
};

const SUBJECTS = [
  { id:'math', hi:'गणित', en:'Mathematics', icon:'fa-square-root-variable', color:'var(--subj-math)', mastery:78, gaps:2, done:14, total:18 },
  { id:'sci',  hi:'विज्ञान', en:'Science', icon:'fa-flask', color:'var(--subj-sci)', mastery:84, gaps:1, done:13, total:16 },
  { id:'soc',  hi:'सामाजिक विज्ञान', en:'Social Science', icon:'fa-earth-asia', color:'var(--subj-soc)', mastery:69, gaps:3, done:9, total:15 },
  { id:'eng',  hi:'अंग्रेज़ी', en:'English', icon:'fa-feather-pointed', color:'var(--subj-eng)', mastery:81, gaps:1, done:11, total:14 },
  { id:'hin',  hi:'हिंदी', en:'Hindi', icon:'fa-book-open', color:'var(--subj-hin)', mastery:88, gaps:0, done:12, total:13 },
];

// This week's assessment
const WEEKLY = {
  week: 14,
  subject: { hi:'गणित', en:'Mathematics' },
  topic: { hi:'पूर्णांक और आँकड़ों का प्रबंधन', en:'Integers & Data Handling' },
  q: 6, mins: 20, due: { hi:'रविवार तक', en:'Due Sunday' },
  competencies: [
    { code:'C-7.3', hi:'पूर्णांकों पर संक्रियाएँ हल करना', en:'Operations on integers' },
    { code:'C-7.4', hi:'पूर्णांकों की तुलना व क्रम', en:'Comparing & ordering integers' },
    { code:'C-7.11', hi:'आँकड़ों का माध्य ज्ञात करना', en:'Finding the mean of data' },
  ],
};

const QUESTIONS = [
  { n:1, type:'mcq', comp:'C-7.3',
    q:{ hi:'(−15) + (+9) का मान क्या है?', en:'What is the value of (−15) + (+9)?' },
    opts:[ {k:'A', hi:'−24', en:'−24'},{k:'B', hi:'−6', en:'−6'},{k:'C', hi:'+6', en:'+6'},{k:'D', hi:'+24', en:'+24'} ],
    correct:1 },
  { n:2, type:'mcq', comp:'C-7.3',
    q:{ hi:'दो ऋणात्मक पूर्णांकों का गुणनफल होता है —', en:'The product of two negative integers is —' },
    opts:[ {k:'A', hi:'ऋणात्मक', en:'Negative'},{k:'B', hi:'धनात्मक', en:'Positive'},{k:'C', hi:'शून्य', en:'Zero'},{k:'D', hi:'कह नहीं सकते', en:'Cannot say'} ],
    correct:1 },
  { n:3, type:'mcq', comp:'C-7.11',
    q:{ hi:'4, 6, 8, 10, 12 का माध्य (mean) क्या है?', en:'What is the mean of 4, 6, 8, 10, 12?' },
    opts:[ {k:'A', hi:'6', en:'6'},{k:'B', hi:'8', en:'8'},{k:'C', hi:'10', en:'10'},{k:'D', hi:'40', en:'40'} ],
    correct:1 },
  { n:4, type:'mcq', comp:'C-7.4',
    q:{ hi:'इनमें सबसे बड़ा पूर्णांक कौन-सा है?', en:'Which of these is the greatest integer?' },
    opts:[ {k:'A', hi:'−3', en:'−3'},{k:'B', hi:'−7', en:'−7'},{k:'C', hi:'0', en:'0'},{k:'D', hi:'−1', en:'−1'} ],
    correct:2 },
  { n:5, type:'subjective', mode:'type', comp:'C-7.3',
    q:{ hi:'एक पनडुब्बी समुद्र-तल से −350 मी पर है। वह 125 मी और नीचे जाती है, फिर 90 मी ऊपर आती है। अंतिम गहराई बताइए। हल भी लिखिए।',
        en:'A submarine is at −350 m. It descends 125 m more, then rises 90 m. Find its final depth. Show your working.' },
    model:{ hi:'−350 − 125 + 90 = −385 मी', en:'−350 − 125 + 90 = −385 m' } },
  { n:6, type:'subjective', mode:'voice', comp:'C-7.3',
    q:{ hi:'समझाइए कि दो ऋणात्मक संख्याओं का गुणनफल धनात्मक क्यों होता है? एक उदाहरण भी दीजिए।',
        en:'Explain why the product of two negative numbers is positive. Give one example.' },
    model:{ hi:'पैटर्न से: (−2)×3=−6, (−2)×2=−4 … (−2)×(−1)=+2, अतः ऋण×ऋण = धन।',
            en:'By the pattern (−2)×3=−6, (−2)×2=−4 … (−2)×(−1)=+2, so negative × negative = positive.' } },
];

// Pre-baked "evaluated" result for the demo
const RESULT = {
  score: 8, max: 12, correctMcq: 3, totalMcq: 4, pct: 67,
  time: { hi:'14 मि 30 से', en:'14m 30s' },
  perQ: [
    { n:1, ok:true,  mark:'2/2' },
    { n:2, ok:true,  mark:'2/2' },
    { n:3, ok:true,  mark:'2/2' },
    { n:4, ok:false, mark:'0/2', chose:0 },
    { n:5, ok:'partial', mark:'1.5/2',
      yours:{ hi:'−350 − 125 = −475, फिर +90 = −385 मी', en:'−350 − 125 = −475, then +90 = −385 m' },
      ai:{ hi:'सही उत्तर! दिशा-चिह्न ठीक लगाए। अगली बार इकाई (मी) हर चरण में लिखें — इसीलिए ½ अंक कम।',
           en:'Correct answer! You applied the signs well. Next time write the unit (m) at every step — that cost you ½ mark.' } },
    { n:6, ok:'partial', mark:'0.5/2',
      yours:{ hi:'क्योंकि दो माइनस मिलकर प्लस बन जाते हैं।', en:'Because two minuses make a plus.' },
      ai:{ hi:'नियम सही है, पर "क्यों" नहीं समझाया और उदाहरण नहीं दिया। पैटर्न-विधि से समझाने का अभ्यास करें।',
           en:'The rule is right, but you did not explain *why* and gave no example. Practise explaining with the pattern method.' } },
  ],
  competencies: [
    { code:'C-7.3', hi:'पूर्णांकों पर संक्रियाएँ', en:'Operations on integers', pct:80, level:'good' },
    { code:'C-7.4', hi:'पूर्णांकों का क्रम', en:'Ordering integers', pct:55, level:'gap' },
    { code:'C-7.11', hi:'आँकड़ों का माध्य', en:'Mean of data', pct:100, level:'strong' },
    { code:'C-7.3b', hi:'वास्तविक जीवन में पूर्णांक', en:'Integers in real life', pct:75, level:'good' },
    { code:'C-7.RE', hi:'गणितीय तर्क व व्याख्या', en:'Reasoning & explanation', pct:40, level:'gap' },
  ],
  gaps: [
    { hi:'ऋणात्मक संख्याओं की तुलना व क्रम', en:'Comparing & ordering negative numbers',
      note:{ hi:'प्रश्न 4 में 0 सबसे बड़ा था — संख्या-रेखा पर अभ्यास ज़रूरी।', en:'In Q4, 0 was greatest — number-line practice needed.' },
      mins:8 },
    { hi:'अपने तर्क को शब्दों में समझाना', en:'Explaining your reasoning in words',
      note:{ hi:'उत्तर सही पर "क्यों" अधूरा — व्याख्या-कौशल पर काम करें।', en:'Answers right but the "why" is incomplete — work on explanation skills.' },
      mins:10 },
  ],
};

// AI Mentor (AINA) seed conversation
const CHAT_SUGGEST = [
  { hi:'प्रश्न 4 कहाँ ग़लत हुआ?', en:'Where did I go wrong in Q4?' },
  { hi:'ऋण × ऋण = धन क्यों?', en:'Why is neg × neg = positive?' },
  { hi:'इस हफ़्ते कैसे तैयारी करूँ?', en:'How should I prepare this week?' },
  { hi:'मेरी कमज़ोरी क्या है?', en:'What is my weak area?' },
];

// Analytics
const TREND = [ {w:'W9',v:58},{w:'W10',v:64},{w:'W11',v:61},{w:'W12',v:72},{w:'W13',v:70},{w:'W14',v:79} ];
const HEAT = [ // 5 subjects × 6 weeks mastery 0-100
  { s:{hi:'गणित',en:'Math'}, c:[55,60,58,70,68,80] },
  { s:{hi:'विज्ञान',en:'Sci'}, c:[62,66,70,72,80,84] },
  { s:{hi:'सा.वि.',en:'SST'}, c:[50,52,58,60,64,69] },
  { s:{hi:'अंग्रेज़ी',en:'Eng'}, c:[70,72,74,78,79,81] },
  { s:{hi:'हिंदी',en:'Hin'}, c:[80,82,84,85,86,88] },
];
const STREAK_DAYS = [1,1,1,1,1,0,1, 1,1,1,1,1,1,1, 1,0,1,1,1,1,1, 1,1,1,1,1,1,0]; // 4 weeks

// Focus areas — specific questions the student got wrong, left partial, or skipped
const FOCUS = [
  { n:4, status:'wrong', comp:'C-7.4', subj:{hi:'गणित',en:'Maths'},
    q:{ hi:'इनमें सबसे बड़ा पूर्णांक कौन-सा है? (−3, −7, 0, −1)', en:'Which is the greatest integer? (−3, −7, 0, −1)' },
    why:{ hi:'आपने −1 चुना — सही उत्तर 0 है।', en:'You chose −1 — the correct answer is 0.' } },
  { n:6, status:'partial', comp:'C-7.3', subj:{hi:'गणित',en:'Maths'},
    q:{ hi:'ऋण × ऋण = धन क्यों होता है? समझाइए।', en:'Why is negative × negative = positive? Explain.' },
    why:{ hi:'उत्तर अधूरा — "क्यों" और उदाहरण नहीं दिया।', en:'Incomplete — the "why" and an example were missing.' } },
  { n:7, status:'skipped', comp:'C-7.11', subj:{hi:'गणित',en:'Maths'},
    q:{ hi:'3, 7, 5, 9 का माध्य (mean) ज्ञात कीजिए।', en:'Find the mean of 3, 7, 5, 9.' },
    why:{ hi:'यह प्रश्न छोड़ दिया गया था।', en:'This question was left unanswered.' } },
];

Object.assign(window, { STUDENT, SUBJECTS, WEEKLY, QUESTIONS, RESULT, CHAT_SUGGEST, TREND, HEAT, STREAK_DAYS, FOCUS });
