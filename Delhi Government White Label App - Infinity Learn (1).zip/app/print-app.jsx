// print-app.jsx — renders every screen stacked, one per page, for PDF export
const PRINT_SCREENS = [
  ['splash',      'Welcome'],
  ['login',       'Sign In'],
  ['home',        'Home — Dashboard'],
  ['tests',       'My Assessments'],
  ['assessIntro', 'Assessment — Intro'],
  ['assessQ',     'Assessment — Question'],
  ['results',     'Results & Analysis'],
  ['progress',    'Progress Report'],
  ['mentor',      'AINA Mentor'],
  ['doubts',      'Ask a Doubt'],
  ['profile',     'Profile'],
];

const PRINT_COMPS = {
  splash: SplashScreen, login: LoginScreen, home: DashboardScreen, tests: TestsScreen,
  assessIntro: AssessIntroScreen, assessQ: AssessQScreen, results: ResultsScreen,
  mentor: MentorScreen, progress: ProgressScreen, profile: ProfileScreen, doubts: DoubtsScreen,
};

window.__appGo = ()=>{};   // screens call go() on interaction; no-op in print

function PrintScreen({ id, label }){
  const Comp = PRINT_COMPS[id];
  const ctx = {
    screen: id, go: ()=>{}, mode: 'full', lang: 'en',
    setLang: ()=>{}, play: 'balanced', openPrefs: ()=>{},
  };
  const accent = ['#1A73E9','#0f4ea3','#eaf2fe'];
  const stageStyle = {
    '--accent': accent[0], '--accent-ink': accent[1], '--accent-soft': accent[2], '--zoom': 1,
    display:'block', width:'auto', height:'auto',
  };
  return (
    <div className="print-page">
      <div className="print-label">{label}</div>
      <div className="stage no-anim" style={stageStyle}>
        <div className="phone">
          <div className="dyn"></div>
          <div className="scr-anim" style={{ width:'100%', height:'100%' }}>
            <AppCtx.Provider value={ctx}><Comp/></AppCtx.Provider>
          </div>
        </div>
      </div>
    </div>
  );
}

function PrintApp(){
  return <React.Fragment>{PRINT_SCREENS.map(([id,label])=> <PrintScreen key={id} id={id} label={label}/>)}</React.Fragment>;
}

ReactDOM.createRoot(document.getElementById('root')).render(<PrintApp/>);
