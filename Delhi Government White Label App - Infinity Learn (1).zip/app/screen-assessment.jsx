// screen-assessment.jsx

// ---------- Tests list ----------
function DueRow({ d, onStart }){
  return (
    <button onClick={onStart} style={{ all:'unset', cursor:'pointer', width:'100%' }}>
      <div className="card" style={{ padding:13, marginBottom:10, display:'flex', alignItems:'center', gap:12, borderLeft:'3px solid '+d.accent }}>
        <span style={{ width:42, height:42, borderRadius:12, background:d.accent+'1f', color:d.accent, display:'flex', alignItems:'center', justifyContent:'center', fontSize:17, flexShrink:0 }}><i className={'fa-solid '+d.icon}></i></span>
        <div style={{ flex:1, minWidth:0 }}>
          <T t={d.topic} tag="div" sec={false} style={{ fontWeight:700, fontSize:14 }}/>
          <div className="tiny" style={{ marginTop:2 }}><Ti t={d.subj}/> · {d.q} <Ti hi="प्रश्न" en="Qs"/> · {d.mins}m</div>
          <div className="row" style={{ gap:6, marginTop:6 }}>
            <span style={{ fontSize:10.5, fontWeight:700, color: d.soon?d.accent:'var(--ink3)', background: d.soon?d.accent+'18':'var(--bg)', padding:'3px 8px', borderRadius:100 }}>
              <i className="fa-regular fa-clock"></i> <Ti t={d.due}/>
            </span>
          </div>
        </div>
        <span style={{ width:34, height:34, borderRadius:'50%', background:d.accent, color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}><i className="fa-solid fa-play" style={{fontSize:12}}></i></span>
      </div>
    </button>
  );
}

function TestsScreen(){
  const { go } = useApp();
  const [tab,setTab] = useState('due');
  const dueToday = DUE_TODAY.filter(d=>!d.tomorrow);
  const upcoming = DUE_TODAY.filter(d=>d.tomorrow);
  const past = [
    { wk:13, t:{hi:'भिन्न व दशमलव',en:'Fractions & Decimals'}, sub:{hi:'गणित',en:'Maths'}, score:'10/12', pct:83, color:'var(--subj-math)' },
    { wk:13, t:{hi:'पादप में पोषण',en:'Nutrition in Plants'}, sub:{hi:'विज्ञान',en:'Science'}, score:'9/10', pct:90, color:'var(--subj-sci)' },
    { wk:12, t:{hi:'हमारे पर्यावरण',en:'Our Environment'}, sub:{hi:'सा. विज्ञान',en:'SST'}, score:'7/12', pct:58, color:'var(--subj-soc)' },
  ];
  return (
    <div className="screen has-nav">
      <StatusBar light bg="var(--accent)"/>
      <Header color="var(--accent)" title={{hi:'मेरे टेस्ट',en:'My Assessments'}} sub={{hi:'साप्ताहिक मूल्यांकन',en:'Weekly evaluations'}}/>
      <div className="body" style={{ marginTop:-12 }}>
        {/* tabs */}
        <div className="px">
          <div className="seg" style={{ background:'#fff', border:'1px solid var(--line)' }}>
            <button className={tab==='due'?'on':''} style={{flexDirection:'row', gap:7}} onClick={()=>setTab('due')}>
              <Ti hi="देय" en="Due"/> <span style={{ fontSize:10.5, fontWeight:800, color:'#fff', background:'var(--magenta)', padding:'1px 7px', borderRadius:100 }}>{dueToday.length}</span>
            </button>
            <button className={tab==='past'?'on':''} style={{flexDirection:'row'}} onClick={()=>setTab('past')}><Ti hi="पिछले" en="Past"/></button>
          </div>
        </div>

        {tab==='due' && (
        <div className="scr-anim">
          {/* due TODAY — swipeable deck */}
          <div className="px row" style={{ justifyContent:'space-between', margin:'18px 0 11px' }}>
            <div className="row" style={{ gap:8 }}>
              <T hi="आज देय" en="Due today" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
              <span style={{ fontSize:11, fontWeight:800, color:'var(--magenta)', background:'#f3ecfb', padding:'3px 9px', borderRadius:100 }}>{dueToday.length}</span>
            </div>
            <span className="tiny"><i className="fa-solid fa-arrows-left-right" style={{fontSize:10}}></i> <Ti hi="स्वाइप" en="Swipe"/></span>
          </div>
          <DueDeck items={dueToday} onStart={()=>go('assessIntro')}/>

          {/* full scrollable list of every due test */}
          <div className="px" style={{ marginTop:22 }}>
            <div style={{ fontWeight:700, fontSize:15, marginBottom:11 }}><Ti hi="सभी देय टेस्ट" en="All due assessments"/></div>
            {dueToday.map((d,i)=> <DueRow key={i} d={d} onStart={()=>go('assessIntro')}/> )}
            {upcoming.length>0 && (
              <>
                <div className="tiny" style={{ fontWeight:700, color:'var(--ink2)', textTransform:'uppercase', letterSpacing:'.04em', margin:'12px 2px 9px' }}><Ti hi="आगामी" en="Upcoming"/></div>
                {upcoming.map((d,i)=> <DueRow key={i} d={d} onStart={()=>go('assessIntro')}/> )}
              </>
            )}
          </div>
        </div>
        )}

        {tab==='past' && (
        <div className="px scr-anim" style={{ marginTop:18 }}>
          <div style={{ fontWeight:700, fontSize:15, margin:'0 2px 12px' }}><Ti hi="पिछले टेस्ट" en="Past assessments"/></div>
          {past.map((p,i)=>(
            <button key={i} onClick={()=>go('results')} style={{ all:'unset', cursor:'pointer', width:'100%' }}>
              <div className="card" style={{ padding:13, marginBottom:10, display:'flex', alignItems:'center', gap:12 }}>
                <span style={{ width:42, height:42, borderRadius:12, background:p.color+'1f', color:p.color, display:'flex', alignItems:'center', justifyContent:'center', fontWeight:800, fontSize:13, flexShrink:0, fontFamily:'var(--en)' }}>W{p.wk}</span>
                <div style={{ flex:1, minWidth:0 }}>
                  <T t={p.t} tag="div" sec={false} style={{ fontWeight:700, fontSize:14 }}/>
                  <div className="tiny"><Ti t={p.sub}/></div>
                </div>
                <div style={{ textAlign:'right' }}>
                  <div style={{ fontWeight:800, fontSize:14, color:p.pct>=80?'var(--ok)':p.pct>=60?'var(--warn)':'var(--bad)', fontFamily:'var(--en)' }}>{p.score}</div>
                  <div className="tiny" style={{ color:'var(--accent)', fontWeight:700 }}><Ti hi="विश्लेषण" en="Analysis"/> ›</div>
                </div>
              </div>
            </button>
          ))}
          <button className="btn btn-ghost" style={{ marginTop:6 }} onClick={()=>go('progress')}>
            <i className="fa-solid fa-chart-pie" style={{color:'var(--accent)'}}></i> <Ti hi="पूरी प्रगति रिपोर्ट देखें" en="View full progress report"/>
          </button>
        </div>
        )}
      </div>
      <BottomNav/>
    </div>
  );
}

// ---------- Assessment intro ----------
function AssessIntroScreen(){
  const { go, mode } = useApp();
  const ess = mode==='essential';
  return (
    <div className="screen">
      <StatusBar light bg="var(--magenta)"/>
      <Header color="var(--magenta)" onBack={()=>go('home')} title={{hi:'साप्ताहिक मूल्यांकन',en:'Weekly Assessment'}} sub={{hi:'सप्ताह 14 · गणित',en:'Week 14 · Mathematics'}}/>
      <div className="body">
        <div className="px" style={{ marginTop:-8 }}>
          <div className="card shadow-card" style={{ padding:17 }}>
            <T t={WEEKLY.topic} tag="div" style={{ fontWeight:700, fontSize:19 }}/>
            <div className="row" style={{ gap:10, marginTop:13, flexWrap:'wrap' }}>
              <div style={{ flex:1, minWidth:90, background:'var(--bg)', borderRadius:12, padding:'11px 12px' }}>
                <div style={{ fontWeight:800, fontSize:18, fontFamily:'var(--en)' }}>{WEEKLY.q}</div>
                <div className="tiny"><Ti hi="प्रश्न" en="Questions"/></div>
              </div>
              <div style={{ flex:1, minWidth:90, background:'var(--bg)', borderRadius:12, padding:'11px 12px' }}>
                <div style={{ fontWeight:800, fontSize:18, fontFamily:'var(--en)' }}>{WEEKLY.mins}<span style={{fontSize:12}}> min</span></div>
                <div className="tiny"><Ti hi="समय" en="Time"/></div>
              </div>
              {!ess && (
              <div style={{ flex:1, minWidth:90, background:'var(--bg)', borderRadius:12, padding:'11px 12px' }}>
                <div style={{ fontWeight:800, fontSize:18, fontFamily:'var(--en)', color:'var(--magenta)' }}>+50</div>
                <div className="tiny">XP</div>
              </div>
              )}
            </div>
          </div>

          <div style={{ fontWeight:700, fontSize:14.5, margin:'20px 2px 10px' }}><Ti hi="NCERT दक्षताएँ जो परखी जाएँगी" en="NCERT competencies covered"/></div>
          {WEEKLY.competencies.map((c,i)=>(
            <div key={i} className="card" style={{ padding:'12px 13px', marginBottom:9, display:'flex', alignItems:'center', gap:11 }}>
              <span style={{ fontSize:11, fontWeight:800, color:'var(--accent)', background:'var(--accent-soft)', padding:'5px 8px', borderRadius:8, flexShrink:0, fontFamily:'var(--en)' }}>{c.code}</span>
              <T t={{hi:c.hi,en:c.en}} tag="div" sec={false} style={{ fontSize:13.5, fontWeight:500 }}/>
            </div>
          ))}

          <div className="card" style={{ padding:14, marginTop:8, background:'var(--accent-soft)', border:'none', display:'flex', gap:11 }}>
            <i className="fa-solid fa-circle-info" style={{ color:'var(--accent)', marginTop:2 }}></i>
            <div style={{ fontSize:12.5, lineHeight:1.5, color:'var(--accent-ink)' }}>
              <T hi="कुछ प्रश्नों में आप टाइप करके, बोलकर या कॉपी की फ़ोटो खींचकर उत्तर दे सकते हैं। AI आपके उत्तर की जाँच करेगा।" en="Some questions let you answer by typing, speaking, or photographing your notebook. AI will evaluate your answers." sec={false}/>
            </div>
          </div>
        </div>
      </div>
      <div className="px" style={{ padding:'12px 18px 16px', background:'#fff', borderTop:'1px solid var(--line)' }}>
        <button className="btn btn-magenta" onClick={()=>go('assessQ')}><Ti hi="टेस्ट शुरू करें" en="Begin Assessment"/> <i className="fa-solid fa-arrow-right"></i></button>
      </div>
    </div>
  );
}

// ---------- Question runner ----------
function AssessQScreen(){
  const { go, lang } = useApp();
  const [i,setI] = useState(0);
  const [ans,setAns] = useState({});         // index -> {mcq, text, mode, voiced, photo}
  const [mode,setMode] = useState('type');
  const [rec,setRec] = useState(false);
  const [confirm,setConfirm] = useState(false);
  const [grading,setGrading] = useState(false);
  const q = QUESTIONS[i];
  const a = ans[i] || {};
  const total = QUESTIONS.length;
  const answeredCount = Object.keys(ans).filter(k=>{ const x=ans[k]; return x && (x.mcq!=null || x.text || x.voiced || x.photo); }).length;

  const setA = (patch)=> setAns(s=>({ ...s, [i]:{ ...s[i], ...patch } }));

  // voice sim
  useEffect(()=>{ if(!rec) return; const id=setTimeout(()=>{
    setRec(false);
    setA({ voiced:true, text: lang==='en'? QUESTIONS[i].model.en : QUESTIONS[i].model.hi });
  }, 2600); return ()=>clearTimeout(id); },[rec]);

  const next = ()=>{ if(i<total-1){ setI(i+1); setMode('type'); } else setConfirm(true); };
  const prev = ()=> i>0 && setI(i-1);

  const submit = ()=>{ setConfirm(false); setGrading(true); setTimeout(()=>go('results'), 2600); };

  if(grading) return <GradingOverlay/>;

  return (
    <div className="screen">
      <StatusBar light bg="var(--accent)"/>
      {/* header */}
      <div style={{ background:'var(--accent)', color:'#fff', padding:'2px 16px 14px' }}>
        <div className="row" style={{ justifyContent:'space-between', minHeight:34 }}>
          <button onClick={()=>go('assessIntro')} style={{ background:'rgba(255,255,255,.18)', border:'none', color:'#fff', width:34, height:34, borderRadius:11, cursor:'pointer' }}><i className="fa-solid fa-xmark"></i></button>
          <span style={{ fontWeight:700, fontSize:14, background:'rgba(255,255,255,.18)', padding:'7px 13px', borderRadius:100 }}><i className="fa-regular fa-clock"></i> 18:42</span>
          <span style={{ width:34, textAlign:'right', fontWeight:700, fontSize:13, paddingTop:8 }}>{i+1}/{total}</span>
        </div>
        {/* progress dots */}
        <div className="row" style={{ gap:6, marginTop:12 }}>
          {QUESTIONS.map((_,k)=>{
            const done = ans[k] && (ans[k].mcq!=null||ans[k].text||ans[k].voiced||ans[k].photo);
            return <div key={k} onClick={()=>setI(k)} style={{ flex:1, height:5, borderRadius:100, cursor:'pointer',
              background: k===i?'#fff':done?'rgba(255,255,255,.85)':'rgba(255,255,255,.3)' }}/>;
          })}
        </div>
      </div>

      <div className="body" key={i}>
        <div className="px scr-anim" style={{ paddingTop:16 }}>
          <div className="row" style={{ gap:8 }}>
            <span style={{ fontSize:11, fontWeight:800, color:'var(--accent)', background:'var(--accent-soft)', padding:'4px 9px', borderRadius:7, fontFamily:'var(--en)' }}>{q.comp}</span>
            <span className="tiny" style={{ fontWeight:700 }}>{q.type==='mcq'? <Ti hi="बहुविकल्पीय" en="Multiple choice"/> : <Ti hi="वर्णनात्मक" en="Subjective"/>}</span>
          </div>
          <T t={q.q} tag="div" style={{ fontSize:17, fontWeight:600, marginTop:12, lineHeight:1.45 }}/>

          {/* MCQ */}
          {q.type==='mcq' && (
            <div style={{ display:'flex', flexDirection:'column', gap:10, marginTop:18 }}>
              {q.opts.map((o,k)=>(
                <button key={k} className={'opt'+(a.mcq===k?' sel':'')} onClick={()=>setA({mcq:k})}>
                  <span className="key">{o.k}</span>
                  <Ti t={{hi:o.hi,en:o.en}} style={{ fontWeight:600, fontSize:15 }}/>
                </button>
              ))}
            </div>
          )}

          {/* Subjective */}
          {q.type==='subjective' && (
            <div style={{ marginTop:16 }}>
              <div className="seg">
                <button className={mode==='type'?'on':''} onClick={()=>setMode('type')}><i className="fa-solid fa-keyboard"></i><Ti hi="टाइप" en="Type"/></button>
                <button className={mode==='voice'?'on':''} onClick={()=>setMode('voice')}><i className="fa-solid fa-microphone"></i><Ti hi="बोलें" en="Voice"/></button>
                <button className={mode==='photo'?'on':''} onClick={()=>setMode('photo')}><i className="fa-solid fa-camera"></i><Ti hi="फ़ोटो" en="Photo"/></button>
              </div>

              {mode==='type' && (
                <div style={{ marginTop:14 }}>
                  <textarea value={a.voiced?'':(a.text||'')} onChange={e=>setA({text:e.target.value, voiced:false})}
                    placeholder={lang==='en'?'Write your answer and working here…':'अपना उत्तर और हल यहाँ लिखें…'}
                    style={{ width:'100%', minHeight:130, border:'1.5px solid var(--line)', borderRadius:14, padding:14, fontSize:15, fontFamily:'var(--hi)', resize:'none', outline:'none', lineHeight:1.5 }}/>
                  <div className="tiny" style={{ marginTop:6 }}><i className="fa-solid fa-wand-magic-sparkles" style={{color:'var(--magenta)'}}></i> <Ti hi="AI आपके चरण-दर-चरण हल की जाँच करेगा" en="AI will check your step-by-step working"/></div>
                </div>
              )}

              {mode==='voice' && (
                <div style={{ marginTop:14, textAlign:'center', padding:'12px 0' }}>
                  <button onClick={()=>setRec(r=>!r)} className={rec?'pulse':''} style={{ width:84, height:84, borderRadius:'50%', border:'none', cursor:'pointer',
                    background: rec?'var(--magenta)':'#fff', color: rec?'#fff':'var(--magenta)', boxShadow: rec?'none':'0 6px 18px -6px rgba(160,102,204,.5)', fontSize:30, border:rec?'none':'2px solid var(--magenta)' }}>
                    <i className={'fa-solid '+(rec?'fa-stop':'fa-microphone')}></i>
                  </button>
                  {rec && <div className="row" style={{ justifyContent:'center', gap:4, height:36, marginTop:14 }}>
                    {[.5,.9,.4,1,.6,.8,.35,.7,.5,.9,.45].map((h,k)=>(<span key={k} className="wv" style={{ height:36, animationDelay:k*.08+'s', transform:`scaleY(${h})` }}/>))}
                  </div>}
                  <div style={{ marginTop:12, fontWeight:600, fontSize:13.5, color:'var(--ink2)' }}>
                    {rec ? <Ti hi="सुन रहा हूँ… बोलते रहो" en="Listening… keep speaking"/> : a.voiced ? <Ti hi="रिकॉर्ड हो गया ✓ दुबारा बोलने के लिए टैप करें" en="Recorded ✓ tap to re-record"/> : <Ti hi="बोलकर उत्तर देने के लिए माइक दबाएँ" en="Tap the mic to answer by voice"/>}
                  </div>
                  {a.voiced && !rec && (
                    <div className="card" style={{ padding:13, marginTop:14, textAlign:'left', background:'var(--magenta-50,#f6f4fd)' }}>
                      <div className="tiny" style={{ fontWeight:700, color:'var(--magenta)', marginBottom:5 }}><i className="fa-solid fa-waveform-lines"></i> <Ti hi="आवाज़ से लिखा गया (Speech-to-Text)" en="Transcribed from speech"/></div>
                      <div className="hi" style={{ fontSize:14, lineHeight:1.5 }}>{a.text}</div>
                    </div>
                  )}
                </div>
              )}

              {mode==='photo' && (
                <div style={{ marginTop:14 }}>
                  {!a.photo ? (
                    <button onClick={()=>setA({photo:true})} style={{ width:'100%', border:'2px dashed var(--line)', background:'#fbfcfe', borderRadius:16, padding:'26px 16px', cursor:'pointer', textAlign:'center' }}>
                      <i className="fa-solid fa-camera" style={{ fontSize:30, color:'var(--accent)' }}></i>
                      <div style={{ fontWeight:700, fontSize:14, marginTop:10 }}><Ti hi="कॉपी में हल लिखकर फ़ोटो खींचें" en="Write in your notebook & take a photo"/></div>
                      <div className="tiny" style={{ marginTop:4 }}><Ti hi="हस्तलेख को AI पढ़ लेगा" en="AI will read your handwriting"/></div>
                    </button>
                  ) : (
                    <div className="card" style={{ overflow:'hidden' }}>
                      <div style={{ position:'relative' }}>
                        <img src={window.__resources.placeholder} style={{ width:'100%', height:150, objectFit:'cover', display:'block' }}/>
                        <div style={{ position:'absolute', inset:0, background:'rgba(20,30,55,.35)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', color:'#fff' }}>
                          <i className="fa-solid fa-check-circle" style={{ fontSize:26 }}></i>
                          <div style={{ fontWeight:700, fontSize:13, marginTop:6 }}><Ti hi="कॉपी की फ़ोटो जोड़ी गई" en="Notebook photo added"/></div>
                        </div>
                      </div>
                      <div style={{ padding:'10px 13px', display:'flex', alignItems:'center', gap:9 }}>
                        <i className="fa-solid fa-wand-magic-sparkles" style={{ color:'var(--magenta)' }}></i>
                        <span className="tiny" style={{ flex:1 }}><Ti hi="AI हस्तलेख पढ़कर हल जाँचेगा" en="AI will read the handwriting & evaluate"/></span>
                        <button className="tiny" style={{ background:'none', border:'none', color:'var(--bad)', fontWeight:700 }} onClick={()=>setA({photo:false})}><Ti hi="हटाएँ" en="Remove"/></button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* footer nav */}
      <div style={{ padding:'11px 16px 16px', background:'#fff', borderTop:'1px solid var(--line)', display:'flex', gap:11 }}>
        {i>0 && <button className="btn btn-ghost" style={{ width:'auto', padding:'14px 20px' }} onClick={prev}><i className="fa-solid fa-arrow-left"></i></button>}
        <button className="btn btn-primary" onClick={next}>
          {i<total-1 ? <Ti hi="अगला प्रश्न" en="Next question"/> : <Ti hi="जमा करें" en="Submit test"/>}
          <i className={'fa-solid '+(i<total-1?'fa-arrow-right':'fa-paper-plane')}></i>
        </button>
      </div>

      {/* confirm sheet */}
      {confirm && (
        <div style={{ position:'absolute', inset:0, background:'rgba(15,20,30,.45)', zIndex:70, display:'flex', alignItems:'flex-end' }} onClick={()=>setConfirm(false)}>
          <div className="scr-anim" onClick={e=>e.stopPropagation()} style={{ background:'#fff', width:'100%', borderRadius:'22px 22px 36px 36px', padding:'22px 20px 26px' }}>
            <div style={{ width:40, height:4, borderRadius:3, background:'var(--line)', margin:'0 auto 16px' }}/>
            <div style={{ textAlign:'center' }}>
              <span style={{ width:54, height:54, borderRadius:'50%', background:'var(--ok-soft)', color:'var(--ok)', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:24 }}><i className="fa-solid fa-paper-plane"></i></span>
              <T hi="टेस्ट जमा करें?" en="Submit your test?" tag="div" style={{ fontWeight:700, fontSize:18, marginTop:12 }}/>
              <div className="muted" style={{ fontSize:13, marginTop:5 }}><Ti hi={answeredCount+' / '+total+' प्रश्न हल किए गए'} en={answeredCount+' of '+total+' questions answered'}/></div>
            </div>
            <button className="btn btn-ok" style={{ marginTop:20 }} onClick={submit}><Ti hi="जमा करें और जाँच कराएँ" en="Submit for AI evaluation"/></button>
            <button className="btn btn-ghost" style={{ marginTop:10 }} onClick={()=>setConfirm(false)}><Ti hi="वापस जाएँ" en="Keep working"/></button>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- AI grading overlay ----------
function GradingOverlay(){
  const steps = [
    { hi:'उत्तर पढ़े जा रहे हैं', en:'Reading your answers' },
    { hi:'चरण-दर-चरण हल जाँचा जा रहा है', en:'Checking step-by-step working' },
    { hi:'NCERT दक्षताओं से मिलान', en:'Mapping to NCERT competencies' },
    { hi:'सीखने की कमियाँ पहचानी जा रही हैं', en:'Identifying learning gaps' },
  ];
  const [s,setS] = useState(0);
  useEffect(()=>{ const id=setInterval(()=>setS(x=>Math.min(x+1,steps.length-1)),600); return ()=>clearInterval(id); },[]);
  return (
    <div className="screen" style={{ background:'linear-gradient(160deg,#101a33,#1d2b52)' }}>
      <StatusBar light bg="#101a33"/>
      <div className="body" style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', color:'#fff', padding:'0 30px' }}>
        <div className="floaty"><Mascot size={84}/></div>
        <T hi="आइना आपके उत्तर जाँच रहा है…" en="AINA is evaluating your answers…" tag="div" style={{ fontWeight:700, fontSize:18, textAlign:'center', marginTop:22 }}/>
        <div style={{ width:'100%', maxWidth:280, marginTop:24, display:'flex', flexDirection:'column', gap:13 }}>
          {steps.map((st,k)=>(
            <div key={k} className="row" style={{ gap:11, opacity:k<=s?1:.35, transition:'opacity .3s' }}>
              <span style={{ width:24, height:24, borderRadius:'50%', flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center', fontSize:11,
                background:k<s?'var(--ok)':k===s?'rgba(255,255,255,.2)':'rgba(255,255,255,.1)' }}>
                {k<s? <i className="fa-solid fa-check"></i> : k===s? <i className="fa-solid fa-spinner fa-spin"></i> : k+1}
              </span>
              <span style={{ fontSize:13.5 }}><Ti t={st}/></span>
            </div>
          ))}
        </div>
      </div>
      <div className="home-ind light"></div>
    </div>
  );
}

Object.assign(window, { TestsScreen, AssessIntroScreen, AssessQScreen, GradingOverlay });
