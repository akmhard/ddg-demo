// screen-dashboard.jsx
function Avatar({ size=46 }){
  return (
    <div style={{ width:size, height:size, borderRadius:'32%', background:'linear-gradient(150deg,#2D6BE3,#1A73E9)', color:'#fff',
      display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:size*.4, flexShrink:0, fontFamily:'var(--en)' }}>नी</div>
  );
}

function StatMini({ icon, color, big, hi, en }){
  return (
    <div className="card" style={{ flex:1, padding:'13px 11px', textAlign:'center' }}>
      <i className={'fa-solid '+icon} style={{ color, fontSize:16 }}></i>
      <div style={{ fontWeight:800, fontSize:20, marginTop:5, fontFamily:'var(--en)' }}>{big}</div>
      <div className="tiny" style={{ lineHeight:1.2, marginTop:2 }}><Ti hi={hi} en={en}/></div>
    </div>
  );
}

function SubjectCard({ s }){
  const { go } = useApp();
  return (
    <button onClick={()=>go('tests')} style={{ all:'unset', cursor:'pointer', width:142, flexShrink:0 }}>
      <div className="card shadow-card" style={{ padding:14 }}>
        <div className="row" style={{ justifyContent:'space-between', alignItems:'flex-start' }}>
          <span style={{ width:36, height:36, borderRadius:11, background:s.color+'1f', color:s.color, display:'flex', alignItems:'center', justifyContent:'center', fontSize:16 }}>
            <i className={'fa-solid '+s.icon}></i>
          </span>
          {s.gaps>0 && <span style={{ fontSize:10, fontWeight:700, color:'var(--warn)', background:'var(--warn-soft)', padding:'3px 7px', borderRadius:100 }}>{s.gaps} <Ti hi="कमी" en="gaps"/></span>}
        </div>
        <T t={{hi:s.hi,en:s.en}} tag="div" style={{ fontWeight:700, fontSize:14, marginTop:10 }}/>
        <div className="row" style={{ justifyContent:'space-between', marginTop:10, marginBottom:5 }}>
          <span className="tiny" style={{fontWeight:700, color:s.color, fontFamily:'var(--en)'}}>{s.mastery}%</span>
          <span className="tiny">{s.done}/{s.total}</span>
        </div>
        <Bar pct={s.mastery} color={s.color} h={6}/>
      </div>
    </button>
  );
}

// ---------- one due-today assessment card ----------
function DueCard({ d, onStart, compact=false }){
  const { mode } = useApp();
  const ess = mode==='essential';
  return (
    <div className="due-card deck-card" style={{ background:d.grad }}>
      <div className="blob"/>
      <div className="row" style={{ justifyContent:'space-between', position:'relative' }}>
        <span style={{ display:'inline-flex', alignItems:'center', gap:7, fontSize:11.5, fontWeight:700, background:'rgba(255,255,255,.22)', padding:'5px 11px', borderRadius:100 }}>
          <i className={'fa-solid '+d.icon}></i> <Ti t={d.subj}/>
        </span>
        <span style={{ fontSize:11, fontWeight:700, background: d.soon?'rgba(255,255,255,.95)':'rgba(255,255,255,.18)', color: d.soon?d.accent:'#fff', padding:'5px 10px', borderRadius:100 }}>
          <i className="fa-regular fa-clock"></i> <Ti t={d.due}/>
        </span>
      </div>
      <T t={d.topic} tag="div" style={{ fontSize:19, fontWeight:700, marginTop:13, lineHeight:1.2 }}/>
      <div className="row" style={{ gap:14, marginTop:11, fontSize:12.5, opacity:.95, whiteSpace:'nowrap' }}>
        <span style={{flexShrink:0}}><i className="fa-regular fa-circle-question"></i> {d.q} <Ti hi="प्रश्न" en="Qs"/></span>
        <span style={{flexShrink:0}}><i className="fa-regular fa-hourglass-half"></i> {d.mins} <Ti hi="मिनट" en="min"/></span>
        {!ess && <span style={{flexShrink:0}}><i className="fa-solid fa-bolt"></i> +{d.xp} XP</span>}
      </div>
      <button className="btn" style={{ marginTop:15, background:'#fff', color:d.accent, fontWeight:700 }} onClick={onStart}>
        <Ti hi="टेस्ट शुरू करें" en="Start Assessment"/> <i className="fa-solid fa-play" style={{fontSize:12}}></i>
      </button>
    </div>
  );
}

// ---------- swipeable deck of due-today cards ----------
function DueDeck({ items, onStart }){
  const ref = useRef();
  const [active,setActive] = useState(0);
  const onScroll = ()=>{
    const el = ref.current; if(!el) return;
    const card = el.querySelector('.deck-card'); if(!card) return;
    const w = card.offsetWidth + 12;
    setActive(Math.round(el.scrollLeft / w));
  };
  return (
    <div>
      <div className="deck" ref={ref} onScroll={onScroll}>
        {items.map((d,i)=> <DueCard key={i} d={d} onStart={()=>onStart(d)}/> )}
      </div>
      <div className="dots">
        {items.map((_,i)=><i key={i} className={i===active?'on':''}/>)}
      </div>
    </div>
  );
}

function DashboardScreen(){
  const { go, mode } = useApp();
  const ess = mode==='essential';
  return (
    <div className="screen has-nav">
      <StatusBar dark/>
      <div className="body">
        {/* greeting */}
        <div className="px row" style={{ justifyContent:'space-between', paddingTop:4, paddingBottom:14 }}>
          <div className="row" style={{ gap:12 }}>
            <Avatar/>
            <div>
              <div style={{ fontSize:12, color:'var(--ink3)' }}><Ti hi="नमस्ते," en="Hello,"/></div>
              <T t={STUDENT.first} tag="div" sec={false} style={{ fontWeight:700, fontSize:17 }}/>
              <div className="tiny"><Ti t={STUDENT.cls}/> · <Ti hi="रोल 23" en="Roll 23"/></div>
            </div>
          </div>
          <div className="row" style={{ gap:8 }}>
            {!ess && <span className="chip" style={{ background:'var(--warn-soft)', color:'#9a6500' }}><i className="fa-solid fa-fire flame" style={{color:'#e8862b'}}></i>{STUDENT.streak}</span>}
          </div>
        </div>

        {/* due today — multiple assessments, swipeable */}
        <div className="px row" style={{ justifyContent:'space-between', marginBottom:10 }}>
          <div className="row" style={{ gap:8 }}>
            <T hi="आज देय टेस्ट" en="Due today" tag="div" sec={false} style={{ fontWeight:700, fontSize:16 }}/>
            <span style={{ fontSize:11, fontWeight:800, color:'var(--magenta)', background:'#f3ecfb', padding:'3px 9px', borderRadius:100 }}>{DUE_TODAY.filter(d=>!d.tomorrow).length}</span>
          </div>
          <button className="tiny" style={{ background:'none', border:'none', color:'var(--accent)', fontWeight:700 }} onClick={()=>go('tests')}><Ti hi="सभी देखें" en="See all"/></button>
        </div>
        <DueDeck items={DUE_TODAY} onStart={(d)=>go('assessIntro')}/>
        <div className="px row" style={{ gap:7, marginTop:9, color:'var(--ink3)', fontSize:11.5 }}>
          <i className="fa-solid fa-hand-pointer" style={{fontSize:11}}></i>
          <Ti hi="स्वाइप करके सभी देय टेस्ट देखें" en="Swipe to see every assessment due"/>
        </div>

        {/* quick stats */}
        {!ess && (
        <div className="px row" style={{ gap:10, marginTop:14 }}>
          <StatMini icon="fa-fire" color="var(--warn)" big={STUDENT.streak} hi="दिन की लय" en="day streak"/>
          <StatMini icon="fa-bullseye" color="var(--ok)" big="79%" hi="औसत सटीकता" en="avg accuracy"/>
          <StatMini icon="fa-award" color="var(--accent)" big="34" hi="दक्षताएँ" en="competencies"/>
        </div>
        )}

        {/* continue learning */}
        <div className="px row" style={{ justifyContent:'space-between', marginTop:22, marginBottom:11 }}>
          <T hi="सीखना जारी रखें" en="Continue Learning" tag="div" sec={false} style={{ fontWeight:700, fontSize:16 }}/>
          <button className="tiny" style={{ background:'none', border:'none', color:'var(--accent)', fontWeight:700 }} onClick={()=>go('tests')}><Ti hi="सभी" en="See all"/></button>
        </div>
        <div style={{ display:'flex', gap:11, overflowX:'auto', padding:'2px 18px 6px' }}>
          {SUBJECTS.map(s => <SubjectCard key={s.id} s={s}/>)}
        </div>

        {/* focus areas — specific questions to revisit */}
        <div className="px" style={{ marginTop:22 }}>
          <div className="row" style={{ gap:8, marginBottom:4 }}>
            <T hi="मज़बूत करने योग्य" en="Areas to Strengthen" tag="div" sec={false} style={{ fontWeight:700, fontSize:16 }}/>
            <span style={{ fontSize:10.5, fontWeight:700, color:'var(--bad)', background:'var(--bad-soft)', padding:'3px 8px', borderRadius:100 }}><Ti hi="AI द्वारा" en="AI-spotted"/></span>
          </div>
          <div className="tiny" style={{ marginBottom:11 }}><Ti hi="छूटे, ग़लत या अधूरे प्रश्न — आइना के साथ दोहराएँ" en="Questions you missed, got wrong or left — revisit them with AINA"/></div>
          {FOCUS.map((fq,i)=> <FocusCard key={i} fq={fq} onAsk={()=>go('mentor')}/> )}
        </div>

        {/* AINA — ask + snap a doubt */}
        <div className="px" style={{ marginTop:6 }}>
          <div style={{ borderRadius:'var(--radius)', background:'linear-gradient(120deg,#101a33,#1d2b52)', color:'#fff', padding:'15px 16px' }}>
            <div className="row" style={{ gap:13, alignItems:'center' }}>
              <Mascot size={44}/>
              <div style={{ flex:1 }}>
                <T hi="आइना से पूछो" en="Ask AINA, your AI Mentor" tag="div" sec={false} style={{ fontWeight:700, fontSize:14.5 }}/>
                <div style={{ fontSize:11.5, opacity:.75, marginTop:2 }}><Ti hi="किसी भी सवाल का हल — कदम-दर-कदम" en="Step-by-step help with any doubt"/></div>
              </div>
            </div>
            <div className="row" style={{ gap:9, marginTop:13 }}>
              <button className="btn" style={{ flex:1, padding:'11px', fontSize:13.5, background:'rgba(255,255,255,.14)', color:'#fff' }} onClick={()=>go('mentor')}>
                <i className="fa-solid fa-comment-dots"></i> <Ti hi="चैट करें" en="Chat"/>
              </button>
              <button className="btn" style={{ flex:1, padding:'11px', fontSize:13.5, background:'#fff', color:'#101a33' }} onClick={()=>go('doubts')}>
                <i className="fa-solid fa-camera"></i> <Ti hi="संदेह पूछें" en="Ask a doubt"/>
              </button>
            </div>
          </div>
        </div>
      </div>
      <BottomNav/>
    </div>
  );
}
// status meta for focus questions
const FOCUS_META = {
  wrong:   { c:'var(--bad)',  bg:'var(--bad-soft)',  ic:'fa-xmark',             hi:'ग़लत',   en:'Incorrect' },
  partial: { c:'var(--warn)', bg:'var(--warn-soft)', ic:'fa-circle-half-stroke', hi:'अधूरा',  en:'Incomplete' },
  skipped: { c:'var(--accent)', bg:'var(--accent-soft)', ic:'fa-forward',        hi:'छोड़ा',  en:'Skipped' },
};
function FocusCard({ fq, onAsk }){
  const m = FOCUS_META[fq.status];
  return (
    <div className="card" style={{ padding:13, marginBottom:10, borderLeft:'3px solid '+m.c }}>
      <div className="row" style={{ gap:8, marginBottom:8 }}>
        <span style={{ display:'inline-flex', alignItems:'center', gap:5, fontSize:10.5, fontWeight:700, color:m.c, background:m.bg, padding:'3px 8px', borderRadius:100 }}>
          <i className={'fa-solid '+m.ic} style={{fontSize:10}}></i><Ti hi={m.hi} en={m.en}/>
        </span>
        <span className="tiny" style={{ fontWeight:700 }}><Ti hi={'प्रश्न '+fq.n} en={'Q'+fq.n}/> · <Ti t={fq.subj}/></span>
        <span style={{ marginLeft:'auto', fontSize:10, fontWeight:800, color:'var(--ink3)', background:'var(--bg)', padding:'2px 7px', borderRadius:6, fontFamily:'var(--en)' }}>{fq.comp}</span>
      </div>
      <T t={fq.q} tag="div" sec={false} style={{ fontWeight:600, fontSize:13.5, lineHeight:1.45 }}/>
      <div className="tiny" style={{ marginTop:6, lineHeight:1.5 }}><Ti t={fq.why}/></div>
      <button className="btn btn-magenta" style={{ marginTop:11, padding:'10px', fontSize:13.5 }} onClick={onAsk}>
        <Mascot size={22}/> <Ti hi="आइना से समझें" en="Understand with AINA"/>
      </button>
    </div>
  );
}

Object.assign(window, { DashboardScreen, Avatar, FocusCard, DueCard, DueDeck });
