// screen-doubts.jsx — AINA-powered "Ask a doubt" flow
// steps: ask → crop → subject → solving → answer

// a believable "photographed notebook page" with the handwritten question
function NotebookShot({ q, scribble=true, style }){
  return (
    <div style={{ background:'linear-gradient(170deg,#fdfdf8,#f3f1e6)', borderRadius:8, padding:'18px 16px 20px', position:'relative', overflow:'hidden',
      backgroundImage:'repeating-linear-gradient(#fdfdf8 0 27px, #cfe0ec 27px 28px)', backgroundSize:'100% 28px', boxShadow:'inset 0 0 40px rgba(120,110,70,.08)', ...style }}>
      <span style={{ position:'absolute', top:0, bottom:0, left:34, width:1.5, background:'#e7a9a0' }}/>
      <div style={{ paddingLeft:14 }}>
        <div style={{ fontSize:10.5, fontWeight:700, color:'#b08968', letterSpacing:'.04em', marginBottom:8, fontFamily:'var(--en)' }}>Q. {scribble && '14'}</div>
        <div style={{ fontFamily:'"Comic Sans MS","Segoe Print",var(--hi)', fontSize:13.5, lineHeight:'28px', color:'#2b3a52' }}>
          <Ti t={q}/>
        </div>
      </div>
    </div>
  );
}

function DoubtHeader({ title, onBack, sub }){
  return (
    <div style={{ background:'linear-gradient(120deg,#101a33,#1d2b52)', color:'#fff', padding:'2px 16px 16px' }}>
      <div className="row" style={{ justifyContent:'space-between', minHeight:34 }}>
        {onBack
          ? <button onClick={onBack} style={{ background:'rgba(255,255,255,.18)', border:'none', color:'#fff', width:34, height:34, borderRadius:11, cursor:'pointer' }}><i className="fa-solid fa-arrow-left"></i></button>
          : <span style={{width:34}}/>}
        <span style={{ fontSize:11, fontWeight:600, opacity:.7, paddingTop:9 }}><i className="fa-solid fa-shield-halved"></i> <Ti hi="सुरक्षित · पाठ्यक्रम आधारित" en="Safe · curriculum-aligned"/></span>
        <span style={{width:34}}/>
      </div>
      <div className="row" style={{ gap:12, marginTop:6 }}>
        <Mascot size={42}/>
        <div>
          <div className="row" style={{ gap:7 }}>
            <T t={title} tag="span" sec={false} style={{ fontWeight:700, fontSize:18 }}/>
            <span style={{ fontSize:10.5, fontWeight:700, background:'rgba(255,255,255,.16)', padding:'2px 8px', borderRadius:100 }}>AINA</span>
          </div>
          <div style={{ fontSize:11.5, opacity:.82, marginTop:2 }}><Ti t={sub}/></div>
        </div>
      </div>
    </div>
  );
}

function DoubtsScreen(){
  const { go, lang } = useApp();
  const en = lang==='en';
  const [step,setStep] = useState('ask');     // ask | crop | subject | solving | answer
  const [text,setText] = useState('');
  const [subj,setSubj] = useState('math');
  const [showSteps,setShowSteps] = useState(false);

  const d = DOUBT_SAMPLE;

  const startSolving = ()=>{ setStep('solving'); setShowSteps(false); setTimeout(()=>setStep('answer'), 2200); };

  // ---------- ASK ----------
  if(step==='ask') return (
    <div className="screen has-nav">
      <StatusBar light bg="#101a33"/>
      <DoubtHeader title={{hi:'संदेह पूछें',en:'Ask a Doubt'}} sub={{hi:'फ़ोटो खींचें या सवाल टाइप करें',en:'Snap a photo or type your question'}}/>
      <div className="body" style={{ padding:'18px 18px 8px' }}>
        <div className="card" style={{ padding:'14px 15px', background:'var(--accent-soft)', border:'none', display:'flex', gap:11, marginBottom:18 }}>
          <Mascot size={30}/>
          <div style={{ fontSize:13, lineHeight:1.5, color:'var(--accent-ink)' }}>
            <Ti hi="नमस्ते नीतू! किसी भी सवाल की फ़ोटो खींचो या टाइप करो — मैं कदम-दर-कदम हल समझाऊँगी।" en="Namaste Neetu! Snap a photo of any question or type it — I’ll explain the solution step by step."/>
          </div>
        </div>

        <div style={{ fontWeight:700, fontSize:15, marginBottom:10 }}><Ti hi="सवाल की फ़ोटो खींचें" en="Take a photo"/></div>
        <button onClick={()=>setStep('crop')} style={{ width:'100%', border:'2px dashed var(--accent)', background:'#fbfcfe', borderRadius:18, padding:'30px 16px', cursor:'pointer', textAlign:'center' }}>
          <span style={{ width:60, height:60, borderRadius:'50%', background:'var(--accent-soft)', color:'var(--accent)', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:26 }}><i className="fa-solid fa-camera"></i></span>
          <div style={{ fontWeight:700, fontSize:15.5, marginTop:12, color:'var(--accent)' }}><Ti hi="फ़ोटो अपलोड करें" en="Upload a photo"/></div>
          <div className="tiny" style={{ marginTop:4 }}><Ti hi="कॉपी या किताब का साफ़ चित्र लें" en="Take a clear picture of your notebook or book"/></div>
        </button>

        <div className="row" style={{ gap:12, margin:'18px 0' }}>
          <span style={{ flex:1, height:1, background:'var(--line)' }}/>
          <span className="tiny" style={{ fontWeight:700 }}><Ti hi="या" en="or"/></span>
          <span style={{ flex:1, height:1, background:'var(--line)' }}/>
        </div>

        <div style={{ fontWeight:700, fontSize:15, marginBottom:10 }}><Ti hi="सवाल टाइप करें" en="Type your question"/></div>
        <div className="login-field row">
          <i className="fa-solid fa-pen" style={{ color:'var(--ink3)' }}></i>
          <input value={text} onChange={e=>setText(e.target.value)}
            placeholder={en?'Type your doubt here…':'अपना सवाल यहाँ लिखें…'}
            style={{ flex:1, border:'none', outline:'none', background:'none', fontSize:14.5, fontFamily:'var(--hi)', color:'var(--ink)' }}/>
        </div>
        <button className="btn btn-primary" style={{ marginTop:14, opacity:text.trim()?1:.5, pointerEvents:text.trim()?'auto':'none' }} onClick={()=>setStep('subject')}>
          <Ti hi="आगे बढ़ें" en="Continue"/> <i className="fa-solid fa-arrow-right"></i>
        </button>
      </div>
      <BottomNav/>
    </div>
  );

  // ---------- CROP ----------
  if(step==='crop') return (
    <div className="screen">
      <StatusBar dark/>
      <DoubtHeader title={{hi:'सवाल काटें',en:'Crop the question'}} sub={{hi:'बॉक्स में सिर्फ़ 1 सवाल रखें',en:'Fit just one question in the box'}} onBack={()=>setStep('ask')}/>
      <div className="body" style={{ background:'#1b1f27', display:'flex', flexDirection:'column' }}>
        <div style={{ flex:1, position:'relative', display:'flex', alignItems:'center', justifyContent:'center', padding:'18px' }}>
          <div style={{ position:'absolute', top:18, left:'50%', transform:'translateX(-50%)', background:'rgba(0,0,0,.55)', color:'#fff', fontSize:12, fontWeight:600, padding:'8px 14px', borderRadius:100, zIndex:5, whiteSpace:'nowrap' }}>
            <i className="fa-regular fa-lightbulb" style={{color:'#ffd66b'}}></i> <Ti hi="बॉक्स घुमाकर 1 सवाल फ़िट करें" en="Adjust the box to fit 1 question"/>
          </div>
          <div style={{ position:'relative', width:'100%', maxWidth:300, borderRadius:12, overflow:'hidden' }}>
            <NotebookShot q={d.q} style={{ minHeight:280 }}/>
            {/* crop frame */}
            <div style={{ position:'absolute', inset:'16% 6% 30%', border:'2px solid #fff', borderRadius:6, boxShadow:'0 0 0 999px rgba(0,0,0,.45)' }}>
              {[['-7px','-7px'],['-7px',null,'-7px'],[null,'-7px','-7px',null],[null,null,'-7px','-7px']].map((c,i)=>(
                <span key={i} style={{ position:'absolute', width:18, height:18, border:'3px solid #fff', borderRadius:3,
                  top:c[0]??'auto', left:c[1]??'auto', right:c[2]??'auto', bottom:c[3]??'auto',
                  borderRight:i%2?undefined:'none', borderBottom:i<2?'none':undefined }}/>
              ))}
            </div>
          </div>
        </div>
        <div style={{ padding:'14px 18px 20px', display:'flex', flexDirection:'column', gap:11 }}>
          <div className="row" style={{ gap:11, justifyContent:'center' }}>
            <button className="btn btn-ghost" style={{ width:'auto', padding:'11px 22px', background:'transparent', color:'#fff', border:'1.5px solid rgba(255,255,255,.4)' }}><i className="fa-solid fa-rotate-left"></i> <Ti hi="रीसेट" en="Reset"/></button>
            <button className="btn btn-ghost" style={{ width:'auto', padding:'11px 22px', background:'transparent', color:'#fff', border:'1.5px solid rgba(255,255,255,.4)' }}><i className="fa-solid fa-crop-simple"></i> <Ti hi="घुमाएँ" en="Rotate"/></button>
          </div>
          <button className="btn btn-primary" onClick={()=>setStep('subject')}><Ti hi="विषय चुनें" en="Select subject"/> <i className="fa-solid fa-arrow-right"></i></button>
        </div>
      </div>
    </div>
  );

  // ---------- SUBJECT ----------
  if(step==='subject') return (
    <div className="screen">
      <StatusBar light bg="#101a33"/>
      <DoubtHeader title={{hi:'विषय चुनें',en:'Select a Subject'}} sub={{hi:'सही हल के लिए विषय बताएँ',en:'Pick the subject for an accurate answer'}} onBack={()=>setStep('ask')}/>
      <div className="body" style={{ padding:'10px 20px 8px' }}>
        {DOUBT_SUBJECTS.map(s=>(
          <button key={s.id} className={'radio-row'+(subj===s.id?' on':'')} onClick={()=>setSubj(s.id)}>
            <span className="radio-ring"></span>
            <Ti t={s} style={{ fontSize:15.5, fontWeight: subj===s.id?700:500 }}/>
          </button>
        ))}
      </div>
      <div style={{ padding:'12px 18px 16px', background:'#fff', borderTop:'1px solid var(--line)', display:'flex', gap:11 }}>
        <button className="btn btn-ghost" style={{ width:'auto', padding:'14px 24px' }} onClick={()=>setStep('ask')}><Ti hi="वापस" en="Back"/></button>
        <button className="btn btn-primary" onClick={startSolving}><Ti hi="आइना से पूछें" en="Ask AINA"/> <i className="fa-solid fa-wand-magic-sparkles"></i></button>
      </div>
    </div>
  );

  // ---------- SOLVING ----------
  if(step==='solving') return (
    <div className="screen" style={{ background:'linear-gradient(160deg,#101a33,#1d2b52)' }}>
      <StatusBar light bg="#101a33"/>
      <div className="body" style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', color:'#fff', padding:'0 30px' }}>
        <div className="floaty"><Mascot size={84}/></div>
        <T hi="आइना आपका सवाल हल कर रही है…" en="AINA is solving your question…" tag="div" sec={false} style={{ fontWeight:700, fontSize:18, textAlign:'center', marginTop:22 }}/>
        <div className="tiny" style={{ color:'rgba(255,255,255,.7)', marginTop:8, textAlign:'center' }}><Ti hi="हस्तलेख पढ़ा जा रहा है · चरण तैयार किए जा रहे हैं" en="Reading your handwriting · preparing steps"/></div>
        <div className="row" style={{ gap:6, marginTop:20 }}>
          {[0,1,2].map(i=><span key={i} style={{ width:9, height:9, borderRadius:'50%', background:'#fff', animation:`floaty 1s ${i*.15}s infinite` }}/>)}
        </div>
      </div>
      <div className="home-ind light"></div>
    </div>
  );

  // ---------- ANSWER ----------
  return (
    <div className="screen has-nav">
      <StatusBar light bg="#101a33"/>
      <DoubtHeader title={{hi:'उत्तर',en:'Get Answers'}} sub={{hi:'चरण-दर-चरण समझाया गया',en:'Explained step by step'}} onBack={()=>setStep('ask')}/>
      <div className="body" style={{ padding:'14px 16px 8px' }}>
        <div className="tiny" style={{ textAlign:'center', marginBottom:12, lineHeight:1.5 }}>
          <Ti hi="इस मंच का उपयोग कर आप इसकी शर्तों से सहमत होते हैं।" en="By using this platform you consent to the terms of this"/> <span style={{ color:'var(--accent)', fontWeight:700 }}><Ti hi="अस्वीकरण" en="Disclaimer"/></span>
        </div>

        {/* the asked question */}
        <div className="row" style={{ gap:8, alignItems:'flex-start', justifyContent:'flex-end', marginBottom:14 }}>
          <div style={{ background:'var(--accent)', color:'#fff', borderRadius:'16px 16px 5px 16px', padding:13, maxWidth:'82%' }}>
            <div style={{ borderRadius:9, overflow:'hidden', marginBottom:9, border:'2px solid rgba(255,255,255,.35)' }}><NotebookShot q={d.q} style={{ minHeight:0, padding:'12px 12px 14px' }}/></div>
            <div style={{ fontSize:11, fontWeight:700, opacity:.9 }}><i className="fa-solid fa-image"></i> <Ti hi="आपकी फ़ोटो" en="Your photo"/> · <Ti t={d.subject}/></div>
          </div>
          <span style={{ width:32, height:32, borderRadius:'50%', background:'var(--accent-soft)', color:'var(--accent-ink)', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:12, flexShrink:0, fontFamily:'var(--en)' }}>नी</span>
        </div>

        {/* AINA intro */}
        <div className="row" style={{ gap:8, alignItems:'flex-end', marginBottom:14 }}>
          <Mascot size={26}/>
          <div className="bubble ai"><Ti hi="नीतू, यह रहा तुम्हारे सवाल का हल —" en="Here’s the solution to what you asked, Neetu —"/></div>
        </div>

        {/* Hint */}
        <div className="hintcard" style={{ marginBottom:13 }}>
          <div className="row" style={{ gap:8, marginBottom:7 }}>
            <i className="fa-solid fa-lightbulb" style={{ color:'#E8A302' }}></i>
            <span style={{ fontWeight:700, fontSize:14 }}><Ti hi="संकेत" en="Hint"/></span>
          </div>
          <T t={d.hint} tag="div" sec={false} style={{ fontSize:13.5, lineHeight:1.55, color:'var(--ink2)' }}/>
        </div>

        {!showSteps ? (
          <button className="btn btn-ok" onClick={()=>setShowSteps(true)}><i className="fa-solid fa-list-ol"></i> <Ti hi="हल के चरण देखें" en="Show solution steps"/></button>
        ) : (
          <div className="scr-anim">
            {/* Solution steps */}
            <div className="solbox" style={{ marginBottom:13 }}>
              <div className="row" style={{ gap:8, marginBottom:13 }}>
                <i className="fa-solid fa-puzzle-piece" style={{ color:'var(--ok)' }}></i>
                <span style={{ fontWeight:700, fontSize:14.5 }}><Ti hi="हल के चरण" en="Solution Steps"/></span>
                <span style={{ marginLeft:'auto', fontSize:10, fontWeight:800, color:'var(--ok)', background:'var(--ok-soft)', padding:'2px 8px', borderRadius:6, fontFamily:'var(--en)' }}>{d.comp}</span>
              </div>
              {d.steps.map(s=>(
                <div key={s.n} className="sol-step">
                  <span className="dot"></span>
                  <div style={{ fontWeight:700, fontSize:12, color:'var(--ok)', marginBottom:3 }}><Ti hi={'चरण '+s.n} en={'Step '+s.n}/></div>
                  <T t={s.t} tag="div" sec={false} style={{ fontSize:13.5, lineHeight:1.55 }}/>
                </div>
              ))}
            </div>

            {/* Final solution */}
            <div className="card" style={{ padding:15, background:'var(--ok-soft)', border:'none', marginBottom:14 }}>
              <div className="row" style={{ gap:8, marginBottom:9 }}>
                <i className="fa-solid fa-circle-check" style={{ color:'var(--ok)' }}></i>
                <span style={{ fontWeight:700, fontSize:14.5 }}><Ti hi="उत्तर" en="Solution"/></span>
              </div>
              <T t={d.solution} tag="div" sec={false} style={{ fontSize:13.5, lineHeight:1.6 }}/>
              <div className="row" style={{ gap:9, marginTop:12, background:'#fff', borderRadius:12, padding:'11px 13px' }}>
                <span className="tiny" style={{ fontWeight:700 }}><Ti hi="अंतिम उत्तर" en="Final answer"/></span>
                <span style={{ marginLeft:'auto', fontWeight:800, fontSize:18, color:'var(--ok)', fontFamily:'var(--en)' }}><Ti t={d.answer}/></span>
              </div>
            </div>

            {/* follow-ups */}
            <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginBottom:6 }}>
              <button className="chip" style={{ background:'#fff', border:'1px solid var(--line)', color:'var(--accent-ink)' }} onClick={()=>go('mentor')}><i className="fa-solid fa-comment-dots" style={{fontSize:10}}></i> <Ti hi="आइना से और पूछें" en="Ask AINA a follow-up"/></button>
              <button className="chip" style={{ background:'#fff', border:'1px solid var(--line)', color:'var(--accent-ink)' }} onClick={()=>{ setStep('ask'); setText(''); }}><i className="fa-solid fa-camera" style={{fontSize:10}}></i> <Ti hi="नया संदेह" en="New doubt"/></button>
            </div>

            <button className="btn btn-ghost" style={{ marginTop:10, color:'var(--ok)', borderColor:'var(--ok)' }} onClick={()=>go('home')}><i className="fa-solid fa-check"></i> <Ti hi="मेरा संदेह हल हो गया" en="My doubt is resolved"/></button>
          </div>
        )}
      </div>
      <BottomNav/>
    </div>
  );
}

Object.assign(window, { DoubtsScreen, NotebookShot });
