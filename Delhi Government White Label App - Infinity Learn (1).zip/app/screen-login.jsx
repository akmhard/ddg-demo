// screen-login.jsx
function LoginScreen(){
  const { go, lang, setLang } = useApp();
  const cycle = ()=> setLang(lang==='bi'?'hi':lang==='hi'?'en':'bi');
  const langLabel = lang==='bi'?'हिं · EN':lang==='hi'?'हिंदी':'ENG';
  return (
    <div className="screen">
      <StatusBar dark/>
      <div className="body" style={{ paddingBottom:0, display:'flex', flexDirection:'column', background:'#fff' }}>
        {/* compact govt identity bar */}
        <div className="px row" style={{ justifyContent:'space-between', alignItems:'center', paddingTop:2, paddingBottom:14 }}>
          <div className="row" style={{ gap:10 }}>
            <img src={window.__resources.emblem} alt="State Emblem of India" style={{ height:34 }}/>
            <div style={{ borderLeft:'1px solid var(--line)', paddingLeft:10, lineHeight:1.3 }}>
              <div style={{ fontSize:10.5, fontWeight:700, color:'var(--ink)' }}><Ti hi="दिल्ली सरकार" en="Govt. of NCT of Delhi"/></div>
              <div style={{ fontSize:9.5, color:'var(--ink2)' }}><Ti hi="शिक्षा निदेशालय" en="Directorate of Education"/></div>
            </div>
          </div>
          <button onClick={cycle} className="row" style={{ gap:6, whiteSpace:'nowrap', background:'var(--accent-soft)', border:'1px solid var(--accent-soft)', color:'var(--accent-ink)', borderRadius:8, padding:'7px 11px', fontSize:11.5, fontWeight:700, cursor:'pointer', fontFamily:'var(--en)' }}>
            <i className="fa-solid fa-globe" style={{fontSize:12}}></i>{langLabel}
          </button>
        </div>
        <div className="row" style={{ height:3 }}>
          <span style={{ flex:1, background:'#FF9933' }}/><span style={{ flex:1, background:'#fff', borderTop:'1px solid var(--line2)', borderBottom:'1px solid var(--line2)' }}/><span style={{ flex:1, background:'#138808' }}/>
        </div>

        {/* compact brand mark */}
        <div className="px row" style={{ gap:13, alignItems:'center', paddingTop:26, paddingBottom:4 }}>
          <span style={{ display:'inline-flex', padding:7, background:'var(--accent-soft)', borderRadius:16 }}><Mascot size={42}/></span>
          <div>
            <div className="hi" style={{ fontSize:23, fontWeight:700, lineHeight:1, color:'var(--ink)' }}>{lang==='en'?'Shiksha Saarthi':'शिक्षा सारथी'}</div>
            <div style={{ fontSize:11, color:'var(--ink2)', marginTop:4, fontWeight:500, letterSpacing:.4, fontFamily:'var(--en)' }}>{lang==='en'?'Learn · Assess · Grow':'SHIKSHA SAARTHI'}</div>
          </div>
        </div>

        {/* login form */}
        <div className="px" style={{ flex:1, display:'flex', flexDirection:'column', paddingTop:24 }}>
          <T hi="पुनः स्वागत है" en="Welcome back" tag="div" sec={false} style={{ fontSize:20, fontWeight:700, letterSpacing:'-.01em' }}/>
          <div style={{ fontSize:13, color:'var(--ink2)', marginTop:4 }}><Ti hi="अपनी आई.डी. से लॉग इन करके आगे बढ़ें" en="Sign in with your student ID to continue"/></div>

          <div style={{ marginTop:24 }}>
            <label style={{ fontSize:11, fontWeight:700, letterSpacing:'.04em', textTransform:'uppercase', color:'var(--ink3)' }}><Ti hi="विद्यार्थी आई.डी." en="Student ID"/></label>
            <div className="row login-field" style={{ marginTop:8 }}>
              <i className="fa-solid fa-id-card" style={{ color:'var(--accent)', width:18, textAlign:'center' }}></i>
              <input defaultValue="DL-7B-23" style={{ border:'none', outline:'none', flex:1, fontSize:15, fontFamily:'var(--en)', fontWeight:600, color:'var(--ink)', background:'none' }}/>
            </div>
          </div>

          <div style={{ marginTop:16 }}>
            <label style={{ fontSize:11, fontWeight:700, letterSpacing:'.04em', textTransform:'uppercase', color:'var(--ink3)' }}><Ti hi="पासवर्ड / OTP" en="Password / OTP"/></label>
            <div className="row login-field" style={{ marginTop:8 }}>
              <i className="fa-solid fa-lock" style={{ color:'var(--accent)', width:18, textAlign:'center' }}></i>
              <input type="password" defaultValue="123456" style={{ border:'none', outline:'none', flex:1, fontSize:15, fontFamily:'var(--en)', letterSpacing:3, color:'var(--ink)', background:'none' }}/>
              <i className="fa-solid fa-eye" style={{ color:'var(--ink3)', cursor:'pointer' }}></i>
            </div>
            <div style={{ textAlign:'right', marginTop:10 }}>
              <button className="tiny" style={{ background:'none', border:'none', color:'var(--accent)', fontWeight:700, cursor:'pointer', padding:0 }}><Ti hi="पासवर्ड भूल गए?" en="Forgot password?"/></button>
            </div>
          </div>

          <button className="btn btn-primary" style={{ marginTop:16 }} onClick={()=>go('home')}>
            <Ti hi="लॉग इन करें" en="Log In"/><i className="fa-solid fa-arrow-right" style={{fontSize:13}}></i>
          </button>

          <div className="row" style={{ gap:12, margin:'16px 0' }}>
            <div style={{ flex:1, height:1, background:'var(--line)' }}/>
            <span className="tiny" style={{ fontWeight:600 }}><Ti hi="या" en="or"/></span>
            <div style={{ flex:1, height:1, background:'var(--line)' }}/>
          </div>

          <button className="btn btn-ghost" onClick={()=>go('home')}>
            <i className="fa-solid fa-mobile-screen" style={{color:'var(--accent)'}}></i><Ti hi="मोबाइल OTP से लॉग इन करें" en="Log in with mobile OTP"/>
          </button>

          <div className="row" style={{ justifyContent:'center', gap:7, marginTop:18, color:'var(--ink3)' }}>
            <i className="fa-solid fa-lock" style={{ fontSize:10 }}></i>
            <span className="tiny"><Ti hi="आपकी जानकारी सुरक्षित एवं गोपनीय है" en="Your information is secure & private"/></span>
          </div>

          <div style={{ marginTop:'auto', paddingTop:18, paddingBottom:20 }}>
            <PoweredBy/>
          </div>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { LoginScreen });
