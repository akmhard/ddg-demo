// screen-mentor.jsx
const AI_REPLIES = {
  0: { // explain Q4
    hi:['प्रश्न 4 में पूछा था — −3, −7, 0, −1 में सबसे बड़ा कौन?','संख्या-रेखा पर जो दाईं ओर होता है वही बड़ा होता है। 0 सभी ऋणात्मक संख्याओं के दाईं ओर है।','इसलिए सही उत्तर **0** है। याद रखो: ऋणात्मक संख्या जितनी बड़ी दिखे, असल में उतनी ही छोटी होती है — −7 < −3।'],
    en:['Question 4 asked — which is greatest among −3, −7, 0, −1?','On the number line, whatever lies further right is greater. 0 lies to the right of every negative number.','So the answer is **0**. Remember: the “bigger-looking” negative is actually smaller — −7 < −3.'] },
  1: { // why neg x neg
    hi:['बढ़िया सवाल! इसे एक पैटर्न से समझते हैं:','(−2) × 3 = −6\n(−2) × 2 = −4\n(−2) × 1 = −2\n(−2) × 0 = 0','हर बार उत्तर **+2** से बढ़ रहा है। आगे बढ़ाएँ:\n(−2) × (−1) = +2\n(−2) × (−2) = +4','इसीलिए ऋण × ऋण = धन। जैसे “मना करना मना है” का मतलब “करो” होता है!'],
    en:['Great question! Let’s see it as a pattern:','(−2) × 3 = −6\n(−2) × 2 = −4\n(−2) × 1 = −2\n(−2) × 0 = 0','Each step the answer goes **up by 2**. Continue the pattern:\n(−2) × (−1) = +2\n(−2) × (−2) = +4','That’s why negative × negative = positive — like a double “no” meaning “yes”!'] },
  2: { // how should I prepare this week (mentorship / planning)
    hi:['अच्छी सोच! तुम्हारे सप्ताह 14 के टेस्ट के आधार पर मैं एक छोटी योजना बनाता हूँ:','1. पूर्णांकों का क्रम (संख्या-रेखा) — 10 मिनट\n2. ऋण × ऋण का कारण — 5 मिनट\n3. माध्य के 2 सवाल — 10 मिनट','रोज़ सिर्फ़ 25 मिनट — रविवार तक तुम तैयार हो जाओगे। शुरू करें?'],
    en:['Good thinking! Based on your Week 14 test, here is a small plan:','1. Ordering integers (number line) — 10 min\n2. Why neg × neg = positive — 5 min\n3. Two questions on finding the mean — 10 min','Just 25 minutes a day — you will be ready by Sunday. Shall we start?'] },
  3: { // weak area
    hi:['तुम्हारे पिछले टेस्टों से दो मुख्य बातें दिखती हैं:','1. **ऋणात्मक संख्याओं का क्रम** — संख्या-रेखा पर अभ्यास चाहिए।\n2. **अपना तर्क शब्दों में समझाना** — उत्तर सही पर «क्यों» अधूरा।','अच्छी खबर — दोनों जल्दी सुधर सकते हैं। पहले किस पर काम करें?'],
    en:['From your recent tests, two things stand out:','1. **Ordering negative numbers** — needs number-line practice.\n2. **Explaining your reasoning in words** — answers are right but the "why" is incomplete.','Good news — both improve fast. Which would you like to work on first?'] },
  default: {
    hi:['मैं तुम्हारी मदद के लिए यहाँ हूँ। तुम मुझसे टेस्ट के किसी प्रश्न का हल, या किसी विषय की व्याख्या पूछ सकते हो।','पढ़ाई से जुड़ी कोई भी उलझन या मार्गदर्शन चाहिए — बेझिझक पूछो।'],
    en:['I’m here to help. You can ask me to solve a test question, or explain any topic step by step.','Any doubt about your studies, or guidance you need — just ask.'] },
};

function Typing(){
  return <div className="bubble ai" style={{ display:'flex', gap:5, padding:'13px 15px' }}>
    {[0,1,2].map(i=><span key={i} style={{ width:7, height:7, borderRadius:'50%', background:'var(--ink3)', animation:`floaty 1s ${i*.15}s infinite` }}/>)}
  </div>;
}

// ---------- in-chat: step-by-step solution card (Hint → Steps → Solution) ----------
function SolutionCardChat(){
  const d = DOUBT_SAMPLE;
  const [showSteps,setShowSteps] = useState(false);
  return (
    <div className="card" style={{ padding:13, background:'#fff', borderColor:'var(--line)', borderBottomLeftRadius:5, maxWidth:'100%' }}>
      <div className="hintcard" style={{ marginBottom:11 }}>
        <div className="row" style={{ gap:7, marginBottom:6 }}>
          <i className="fa-solid fa-lightbulb" style={{ color:'#E8A302' }}></i>
          <span style={{ fontWeight:700, fontSize:13 }}><Ti hi="संकेत" en="Hint"/></span>
        </div>
        <T t={d.hint} tag="div" sec={false} style={{ fontSize:13, lineHeight:1.55, color:'var(--ink2)' }}/>
      </div>
      {!showSteps ? (
        <button className="btn btn-ok" style={{ padding:'11px', fontSize:13.5 }} onClick={()=>setShowSteps(true)}><i className="fa-solid fa-list-ol"></i> <Ti hi="हल के चरण देखें" en="Show solution steps"/></button>
      ) : (
        <div className="scr-anim">
          <div className="solbox" style={{ marginBottom:11 }}>
            <div className="row" style={{ gap:8, marginBottom:12 }}>
              <i className="fa-solid fa-puzzle-piece" style={{ color:'var(--ok)' }}></i>
              <span style={{ fontWeight:700, fontSize:13.5 }}><Ti hi="हल के चरण" en="Solution Steps"/></span>
            </div>
            {d.steps.map(s=>(
              <div key={s.n} className="sol-step">
                <span className="dot"></span>
                <div style={{ fontWeight:700, fontSize:11.5, color:'var(--ok)', marginBottom:3 }}><Ti hi={'चरण '+s.n} en={'Step '+s.n}/></div>
                <T t={s.t} tag="div" sec={false} style={{ fontSize:13, lineHeight:1.55 }}/>
              </div>
            ))}
          </div>
          <div className="row" style={{ gap:9, background:'var(--ok-soft)', borderRadius:12, padding:'11px 13px' }}>
            <span className="tiny" style={{ fontWeight:700 }}><Ti hi="अंतिम उत्तर" en="Final answer"/></span>
            <span style={{ marginLeft:'auto', fontWeight:800, fontSize:17, color:'var(--ok)', fontFamily:'var(--en)' }}><Ti t={d.answer}/></span>
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- in-chat: guided study plan with check-offs ----------
function PlanCardChat(){
  const p = STUDY_PLAN;
  const [checks,setChecks] = useState(()=> p.days.map(dd=> dd.tasks.map(t=>!!t.done)));
  const all = checks.flat();
  const done = all.filter(Boolean).length;
  const toggle = (di,ti)=> setChecks(cs=> cs.map((d,i)=> i!==di? d : d.map((v,j)=> j===ti? !v : v)));
  return (
    <div className="card" style={{ padding:14, background:'#fff', borderColor:'var(--line)', borderBottomLeftRadius:5, maxWidth:'100%' }}>
      <div className="row" style={{ gap:9, marginBottom:3 }}>
        <span style={{ width:30, height:30, borderRadius:9, background:'var(--accent-soft)', color:'var(--accent)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}><i className="fa-solid fa-calendar-check"></i></span>
        <T t={p.title} tag="div" sec={false} style={{ fontWeight:700, fontSize:14.5 }}/>
      </div>
      <div className="tiny" style={{ marginBottom:11 }}><Ti t={p.sub}/></div>
      <div className="row" style={{ gap:9, marginBottom:13 }}>
        <div className="bar" style={{ flex:1 }}><i style={{ width:(done/all.length*100)+'%', background:'var(--ok)' }}></i></div>
        <span className="tiny" style={{ fontWeight:800, fontFamily:'var(--en)', color:'var(--ok)' }}>{done}/{all.length}</span>
      </div>
      {p.days.map((dd,di)=>(
        <div key={di} style={{ marginBottom: di<p.days.length-1?14:0 }}>
          <div className="row" style={{ justifyContent:'space-between', marginBottom:8 }}>
            <span style={{ fontWeight:700, fontSize:12.5 }}><Ti t={dd.day}/></span>
            <span className="tiny" style={{ fontFamily:'var(--en)' }}>~{dd.mins} min</span>
          </div>
          <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
            {dd.tasks.map((tk,ti)=>{
              const on = checks[di][ti];
              return (
                <button key={ti} onClick={()=>toggle(di,ti)} style={{ all:'unset', cursor:'pointer', display:'flex', alignItems:'center', gap:11 }}>
                  <span className={'plan-check'+(on?' done':'')}><i className="fa-solid fa-check" style={{fontSize:11}}></i></span>
                  <Ti t={tk.t} style={{ fontSize:13, fontWeight:500, flex:1, textDecoration:on?'line-through':'none', color:on?'var(--ink3)':'var(--ink)' }}/>
                  <span className="tiny" style={{ fontFamily:'var(--en)', flexShrink:0 }}>{tk.mins}m</span>
                </button>
              );
            })}
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------- in-chat: practice-a-similar-question loop ----------
function PracticeCardChat(){
  const { lang } = useApp();
  const q = PRACTICE_Q;
  const [sel,setSel] = useState(null);
  const answered = sel!=null;
  const correct = sel===q.correct;
  return (
    <div className="card" style={{ padding:14, background:'#fff', borderColor:'var(--line)', borderBottomLeftRadius:5, maxWidth:'100%' }}>
      <div className="row" style={{ gap:8, marginBottom:10 }}>
        <span style={{ fontSize:10.5, fontWeight:800, color:'var(--magenta)', background:'#f3ecfb', padding:'3px 8px', borderRadius:7 }}><Ti hi="अभ्यास" en="Practice"/></span>
        <span style={{ fontSize:10, fontWeight:800, color:'var(--ink3)', background:'var(--bg)', padding:'3px 7px', borderRadius:6, fontFamily:'var(--en)' }}>{q.comp}</span>
      </div>
      <T t={q.q} tag="div" sec={false} style={{ fontSize:14.5, fontWeight:600, lineHeight:1.45, marginBottom:12 }}/>
      <div style={{ display:'flex', flexDirection:'column', gap:8 }}>
        {q.opts.map((o,k)=>{
          let cls = 'opt';
          if(answered){
            if(k===q.correct) cls='opt correct';
            else if(k===sel) cls='opt wrong';
          } else if(k===sel) cls='opt sel';
          return (
            <button key={k} className={cls} style={{ padding:'11px 13px', pointerEvents:answered?'none':'auto' }} onClick={()=>setSel(k)}>
              <span className="key" style={{ width:26, height:26, fontSize:12 }}>{o.k}</span>
              <Ti t={{hi:o.hi,en:o.en}} style={{ fontWeight:600, fontSize:14, flex:1 }}/>
              {answered && k===q.correct && <i className="fa-solid fa-check" style={{ color:'var(--ok)' }}></i>}
              {answered && k===sel && !correct && <i className="fa-solid fa-xmark" style={{ color:'var(--bad)' }}></i>}
            </button>
          );
        })}
      </div>
      {answered && (
        <div className="scr-anim card" style={{ marginTop:12, padding:'11px 12px', border:'none', background: correct?'var(--ok-soft)':'var(--warn-soft)', display:'flex', gap:9 }}>
          <i className={'fa-solid '+(correct?'fa-circle-check':'fa-circle-info')} style={{ color: correct?'var(--ok)':'#9a6500', marginTop:1 }}></i>
          <T t={correct?q.explainOk:q.explainNo} tag="div" sec={false} style={{ fontSize:12.8, lineHeight:1.55 }}/>
        </div>
      )}
    </div>
  );
}

function MentorScreen(){
  const { lang } = useApp();
  const en = lang==='en';
  const [msgs,setMsgs] = useState([{ who:'ai', text: en?'Namaste Neetu! I’m AINA, your AI mentor. I saw your Week 14 test — want me to explain where you lost marks?':'नमस्ते नीतू! मैं आइना हूँ, तुम्हारा AI मेंटर। मैंने तुम्हारा सप्ताह 14 का टेस्ट देखा — बताऊँ कहाँ अंक छूटे?' }]);
  const [typing,setTyping] = useState(false);
  const [input,setInput] = useState('');
  const bodyRef = useRef();

  useEffect(()=>{ if(bodyRef.current) bodyRef.current.scrollTop = bodyRef.current.scrollHeight; },[msgs,typing]);

  const reply = (key)=>{
    setTyping(true);
    const pack = (AI_REPLIES[key]||AI_REPLIES.default)[en?'en':'hi'];
    let d=600;
    pack.forEach((line,idx)=>{
      setTimeout(()=>{
        setTyping(idx<pack.length-1);
        setMsgs(m=>[...m,{who:'ai',text:line}]);
        if(idx<pack.length-1) setTyping(true);
      }, d);
      d += 700 + line.length*8;
    });
  };

  const send = (text, key)=>{
    if(!text.trim() && key==null) return;
    setMsgs(m=>[...m,{who:'me',text}]);
    setInput('');
    reply(key);
  };

  const pushAi = (text)=> setMsgs(m=>[...m,{who:'ai',text}]);
  const pushCardAfter = (lead, kind, delay=950)=>{
    setTyping(true);
    setTimeout(()=>{ setTyping(false); pushAi(lead); setMsgs(m=>[...m,{who:'ai',kind}]); }, delay);
  };

  // suggestion chips — "prepare" returns a guided plan, others reply with text
  const handleSuggest = (s, key)=>{
    setMsgs(m=>[...m,{who:'me',text: en?s.en:s.hi}]);
    if(key===2) pushCardAfter(en?'Good thinking! Here’s a short plan from your Week 14 gaps — tick tasks off as you go:':'अच्छी सोच! सप्ताह 14 की कमियों से बनी एक छोटी योजना — पूरा करते हुए टिक करते जाओ:', 'plan');
    else reply(key);
  };
  const askPractice = ()=>{
    setMsgs(m=>[...m,{who:'me', text: en?'Give me a similar question to practise':'अभ्यास के लिए एक मिलता-जुलता सवाल दो'}]);
    pushCardAfter(en?'Sure! Try this one — take your time:':'ज़रूर! यह सवाल आज़माओ — आराम से सोचो:', 'practice');
  };
  const askPlan = ()=>{
    setMsgs(m=>[...m,{who:'me', text: en?'Make me a study plan':'मेरे लिए पढ़ाई की योजना बनाओ'}]);
    pushCardAfter(en?'Here’s a short plan from your Week 14 gaps — tick tasks off as you go:':'सप्ताह 14 की कमियों से बनी एक छोटी योजना — पूरा करते हुए टिक करते जाओ:', 'plan');
  };
  const solvePhoto = ()=>{
    setMsgs(m=>[...m,{who:'me', kind:'photo'}]);
    pushCardAfter(en?'Got it — I’ve read your photo. Here’s the step-by-step solution:':'समझ गई — मैंने तुम्हारी फ़ोटो पढ़ ली। यह रहा कदम-दर-कदम हल:', 'solution', 1500);
  };

  return (
    <div className="screen has-nav">
      <StatusBar light bg="#101a33"/>
      {/* header */}
      <div style={{ background:'linear-gradient(120deg,#101a33,#1d2b52)', color:'#fff', padding:'2px 16px 14px' }}>
        <div className="row" style={{ justifyContent:'space-between', minHeight:30 }}>
          <span style={{ width:30 }}/>
          <span style={{ fontSize:11, fontWeight:600, opacity:.7 }}><i className="fa-solid fa-shield-halved"></i> <Ti hi="सुरक्षित · पाठ्यक्रम आधारित" en="Safe · curriculum-aligned"/></span>
          <span style={{ width:30 }}/>
        </div>
        <div className="row" style={{ gap:12, marginTop:4 }}>
          <span className="floaty"><Mascot size={48}/></span>
          <div style={{ flex:1 }}>
            <div className="row" style={{ gap:7 }}>
              <span className="hi" style={{ fontWeight:700, fontSize:18 }}>आइना</span>
              <span style={{ fontSize:11, fontWeight:700, background:'rgba(255,255,255,.16)', padding:'2px 8px', borderRadius:100 }}>AI Mentor</span>
            </div>
            <div className="row" style={{ gap:6, fontSize:11.5, opacity:.85, marginTop:2 }}>
              <span style={{ width:7, height:7, borderRadius:'50%', background:'#3ddc84' }}/><Ti hi="टेस्ट, संदेह और पढ़ाई में मार्गदर्शन" en="Tests, doubts & study guidance"/>
            </div>
          </div>
        </div>
      </div>

      {/* chat body */}
      <div className="body" ref={bodyRef} style={{ padding:'16px 16px 8px', display:'flex', flexDirection:'column', gap:10, background:'var(--bg)' }}>
        {msgs.map((m,k)=>{
          if(m.who==='ai' && m.kind){
            return (
              <div key={k} className="row" style={{ gap:8, alignItems:'flex-start' }}>
                <Mascot size={26}/>
                <div style={{ flex:1, minWidth:0 }}>
                  {m.kind==='solution' && <SolutionCardChat/>}
                  {m.kind==='plan' && <PlanCardChat/>}
                  {m.kind==='practice' && <PracticeCardChat/>}
                </div>
              </div>
            );
          }
          if(m.who==='me' && m.kind==='photo'){
            return (
              <div key={k} className="row" style={{ justifyContent:'flex-end' }}>
                <div style={{ borderRadius:'16px 16px 5px 16px', overflow:'hidden', maxWidth:'62%', border:'3px solid var(--accent)' }}>
                  <NotebookShot q={DOUBT_SAMPLE.q} style={{ minHeight:0, padding:'12px 12px 14px' }}/>
                  <div className="tiny" style={{ background:'var(--accent)', color:'#fff', padding:'5px 9px', fontWeight:600 }}><i className="fa-solid fa-camera" style={{fontSize:10}}></i> <Ti hi="संदेह की फ़ोटो" en="Doubt photo"/></div>
                </div>
              </div>
            );
          }
          return (
            <div key={k} className="row" style={{ gap:8, alignItems:'flex-end', justifyContent:m.who==='me'?'flex-end':'flex-start' }}>
              {m.who==='ai' && <Mascot size={26}/>}
              <div className={'bubble '+(m.who==='ai'?'ai':'me')} style={{ whiteSpace:'pre-wrap' }}>{renderRich(m.text)}</div>
            </div>
          );
        })}
        {typing && <div className="row" style={{ gap:8, alignItems:'flex-end' }}><Mascot size={26}/><Typing/></div>}

        {/* suggestion chips */}
        {msgs.length<=2 && !typing && (
          <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginTop:6 }}>
            {CHAT_SUGGEST.map((s,k)=>(
              <button key={k} className="chip" style={{ background:'#fff', border:'1px solid var(--line)', color:'var(--accent-ink)' }}
                onClick={()=>handleSuggest(s, k)}><i className="fa-solid fa-wand-magic-sparkles" style={{fontSize:10}}></i> <Ti t={s}/></button>
            ))}
          </div>
        )}
      </div>

      {/* quick actions */}
      <div style={{ display:'flex', gap:8, overflowX:'auto', padding:'8px 12px 0', background:'#fff' }}>
        <button className="chip" style={{ background:'var(--magenta)', color:'#fff', flexShrink:0 }} onClick={solvePhoto}><i className="fa-solid fa-camera" style={{fontSize:11}}></i> <Ti hi="फ़ोटो से हल करें" en="Solve from photo"/></button>
        <button className="chip" style={{ background:'var(--accent-soft)', color:'var(--accent-ink)', flexShrink:0 }} onClick={askPractice}><i className="fa-solid fa-pen-to-square" style={{fontSize:11}}></i> <Ti hi="अभ्यास प्रश्न" en="Practice question"/></button>
        <button className="chip" style={{ background:'var(--accent-soft)', color:'var(--accent-ink)', flexShrink:0 }} onClick={askPlan}><i className="fa-solid fa-calendar-check" style={{fontSize:11}}></i> <Ti hi="पढ़ाई की योजना" en="Study plan"/></button>
      </div>

      {/* input bar */}
      <div style={{ background:'#fff', borderTop:'1px solid var(--line)', padding:'10px 12px' }}>
        <div className="row" style={{ gap:9 }}>
          <div className="row" style={{ flex:1, background:'var(--bg)', borderRadius:100, padding:'4px 6px 4px 16px' }}>
            <input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send(input,null)}
              placeholder={en?'Ask AINA anything…':'आइना से कुछ भी पूछो…'}
              style={{ flex:1, border:'none', background:'none', outline:'none', fontSize:14.5, fontFamily:'var(--hi)', color:'var(--ink)' }}/>
            <button onClick={()=>send(input,null)} style={{ width:38, height:38, borderRadius:'50%', border:'none', background: input.trim()?'var(--accent)':'var(--line)', color:'#fff', cursor:'pointer', flexShrink:0 }}><i className="fa-solid fa-arrow-up"></i></button>
          </div>
        </div>
      </div>
      <BottomNav/>
    </div>
  );
}

// render **bold** within text
function renderRich(text){
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((p,i)=> p.startsWith('**') ? <strong key={i}>{p.slice(2,-2)}</strong> : <span key={i}>{p}</span>);
}

Object.assign(window, { MentorScreen });
