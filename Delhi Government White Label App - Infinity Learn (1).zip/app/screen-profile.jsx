// screen-profile.jsx
function ProfileScreen(){
  const { go, lang, setLang, mode } = useApp();
  const ess = mode==='essential';
  const badges = [
    { ic:'fa-fire', c:'var(--warn)', hi:'12 दिन की लय', en:'12-day streak' },
    { ic:'fa-bolt', c:'var(--magenta)', hi:'1840 XP', en:'1840 XP' },
    { ic:'fa-medal', c:'var(--accent)', hi:'गणित नायक', en:'Maths Hero' },
    { ic:'fa-star', c:'var(--ok)', hi:'पूर्ण सप्ताह', en:'Perfect week' },
  ];
  const langName = { hi:'हिंदी', en:'English', bi:'हिंदी + English' };
  return (
    <div className="screen has-nav">
      <StatusBar light bg="#1f5fd0"/>
      <div style={{ background:'linear-gradient(160deg,#1f5fd0,#1A73E9)', color:'#fff', padding:ess?'6px 18px 22px':'6px 18px 46px', textAlign:'center', position:'relative' }}>
        <div className="row" style={{ justifyContent:'flex-end', minHeight:30 }}>
          <button style={{ background:'rgba(255,255,255,.18)', border:'none', color:'#fff', width:34, height:34, borderRadius:11, cursor:'pointer' }}><i className="fa-solid fa-gear"></i></button>
        </div>
        <div style={{ width:78, height:78, borderRadius:'30%', background:'rgba(255,255,255,.2)', border:'3px solid rgba(255,255,255,.5)', margin:'4px auto 0', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:700, fontSize:30, fontFamily:'var(--en)' }}>नी</div>
        <T t={STUDENT.name} tag="div" sec={false} style={{ fontWeight:700, fontSize:19, marginTop:11 }}/>
        <div style={{ fontSize:12.5, opacity:.9, marginTop:3 }}><Ti t={STUDENT.cls}/> · <Ti hi="रोल 23" en="Roll 23"/></div>
        <div style={{ fontSize:11.5, opacity:.8, marginTop:2 }}><Ti t={STUDENT.school}/></div>
      </div>

      <div className="body" style={{ marginTop:ess?0:-30, display:'flex', flexDirection:'column' }}>
        {/* badges */}
        {!ess && (
        <div className="px">
          <div className="card shadow-card" style={{ padding:'14px 8px', display:'flex' }}>
            {badges.map((b,k)=>(
              <div key={k} style={{ flex:1, textAlign:'center' }}>
                <span style={{ width:42, height:42, borderRadius:13, background:b.c+'1f', color:b.c, display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:17 }}><i className={'fa-solid '+b.ic}></i></span>
                <div className="tiny" style={{ marginTop:6, lineHeight:1.2 }}><Ti hi={b.hi} en={b.en}/></div>
              </div>
            ))}
          </div>
        </div>
        )}

        {/* settings */}
        <div className="px" style={{ marginTop:ess?18:20 }}>
          <T hi="सेटिंग्स" en="Settings" tag="div" sec={false} style={{ fontWeight:700, fontSize:15, marginBottom:11 }}/>
          <div className="card">
            {/* language — full version only (essential is English-only) */}
            {!ess && (
            <div style={{ padding:'13px 15px', borderBottom:'1px solid var(--line2)' }}>
              <div className="row" style={{ gap:12 }}>
                <i className="fa-solid fa-language" style={{ color:'var(--accent)', width:20, textAlign:'center' }}></i>
                <span style={{ flex:1, fontSize:14, fontWeight:600 }}><Ti hi="भाषा" en="Language"/></span>
              </div>
              <div className="seg" style={{ marginTop:11 }}>
                {[['hi','हिंदी'],['en','English'],['bi','दोनों']].map(([v,l])=>(
                  <button key={v} className={lang===v?'on':''} onClick={()=>setLang(v)} style={{ flexDirection:'row' }}>{l}</button>
                ))}
              </div>
            </div>
            )}
            {(ess
              ? [
                  { ic:'fa-circle-question', hi:'सहायता', en:'Help & support', val:null },
                  { ic:'fa-circle-info', hi:'ऐप के बारे में', en:'About this app', val:null },
                ]
              : [
                  { ic:'fa-circle-half-stroke', hi:'टेक्स्ट का आकार', en:'Text size', val:{hi:'सामान्य',en:'Normal'} },
                  { ic:'fa-download', hi:'ऑफ़लाइन पाठ', en:'Offline lessons', val:{hi:'3 सहेजे',en:'3 saved'} },
                  { ic:'fa-circle-question', hi:'सहायता', en:'Help & support', val:null },
                ]
            ).map((r,k,arr)=>(
              <div key={k} className="row" style={{ padding:'14px 15px', gap:12, borderBottom:k<arr.length-1?'1px solid var(--line2)':'none', cursor:'pointer' }}>
                <i className={'fa-solid '+r.ic} style={{ color:'var(--accent)', width:20, textAlign:'center' }}></i>
                <span style={{ flex:1, fontSize:14, fontWeight:600 }}><Ti hi={r.hi} en={r.en}/></span>
                {r.val && <span className="tiny"><Ti t={r.val}/></span>}
                <i className="fa-solid fa-chevron-right" style={{ color:'var(--ink3)', fontSize:11 }}></i>
              </div>
            ))}
          </div>
        </div>

        <div className="px" style={{ marginTop:'auto', paddingTop:18, paddingBottom:8 }}>
          <button className="btn btn-ghost" style={{ color:'var(--bad)' }} onClick={()=>go('login')}><i className="fa-solid fa-right-from-bracket"></i> <Ti hi="लॉग आउट" en="Log out"/></button>
          <div style={{ marginTop:18 }}>
            <PoweredBy/>
            <div className="tiny" style={{ textAlign:'center', marginTop:8, opacity:.6 }}>v1.0</div>
          </div>
        </div>
      </div>
      <BottomNav/>
    </div>
  );
}
Object.assign(window, { ProfileScreen });
