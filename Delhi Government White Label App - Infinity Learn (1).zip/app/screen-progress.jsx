// screen-progress.jsx — Cumulative / meta progress report
function heatColor(v){
  if(v>=85) return '#1565c0';
  if(v>=75) return '#2D6BE3';
  if(v>=65) return '#6f9eed';
  if(v>=55) return '#a9c5f3';
  return '#dde8fb';
}

// accuracy → colour band
function band(acc){
  if(acc==null) return { key:'untaught', c:'#9aa3ad', soft:'#f1f3f6', l:{hi:'अभी नहीं पढ़ा',en:'Not taught yet'} };
  if(acc>=80)   return { key:'exc',  c:'#1E9E54', soft:'#e6f6ec', l:{hi:'उत्कृष्ट (80–100%)',en:'Excellent (80–100%)'} };
  if(acc>=60)   return { key:'good', c:'#2D6BE3', soft:'#e9f1fd', l:{hi:'अच्छा (60–79%)',en:'Good (60–79%)'} };
  if(acc>=40)   return { key:'avg',  c:'#E8862B', soft:'#fdf0e2', l:{hi:'औसत (40–59%)',en:'Average (40–59%)'} };
  return                { key:'weak', c:'#D43B30', soft:'#fbe8e6', l:{hi:'सुधार आवश्यक (<40%)',en:'Needs work (<40%)'} };
}

// ---------- recent tests carousel ----------
function RecentTestsDeck(){
  const ref = useRef();
  const [active,setActive] = useState(0);
  const onScroll = ()=>{ const el=ref.current; if(!el) return; const c=el.querySelector('.deck-card'); if(!c) return; setActive(Math.round(el.scrollLeft/(c.offsetWidth+12))); };
  return (
    <div>
      <div className="deck" ref={ref} onScroll={onScroll}>
        {RECENT_TESTS.map((tt,i)=>(
          <div key={i} className="deck-card card" style={{ padding:15, flexBasis:'88%' }}>
            <div className="row" style={{ justifyContent:'space-between', alignItems:'flex-start' }}>
              <div style={{ minWidth:0 }}>
                <T t={tt.name} tag="div" sec={false} style={{ fontWeight:700, fontSize:15 }}/>
                <div className="tiny" style={{ marginTop:2, fontFamily:'var(--en)' }}>{tt.date}</div>
              </div>
              <span style={{ fontSize:10.5, fontWeight:700, color:'#9a6500', background:'var(--warn-soft)', padding:'3px 9px', borderRadius:100, flexShrink:0 }}><Ti t={tt.tag}/></span>
            </div>
            <div className="row" style={{ gap:14, marginTop:13 }}>
              <Ring pct={tt.pct} size={74} stroke={8} color={tt.color}>
                <div style={{ fontWeight:800, fontSize:15, fontFamily:'var(--en)' }}>{tt.pct}%</div>
              </Ring>
              <div style={{ flex:1 }}>
                <div className="tiny"><Ti hi="स्कोर" en="Score"/></div>
                <div style={{ fontWeight:800, fontSize:22, fontFamily:'var(--en)', color:tt.color, lineHeight:1.1 }}>{tt.score}<span style={{ fontSize:14, color:'var(--ink3)' }}> / {tt.max}</span></div>
              </div>
            </div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8, marginTop:13 }}>
              {tt.stats.map((st,k)=>(
                <div key={k} style={{ background:'var(--bg)', borderRadius:10, padding:'8px 10px' }}>
                  <div className="tiny" style={{ lineHeight:1.2 }}><Ti t={st.l}/></div>
                  <div style={{ fontWeight:800, fontSize:14, fontFamily:'var(--en)', marginTop:2 }}>{st.v}</div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="dots">{RECENT_TESTS.map((_,i)=><i key={i} className={i===active?'on':''}/>)}</div>
    </div>
  );
}

// ---------- expandable subject performance card ----------
function SubjectPerfCard({ sp, open, onToggle }){
  const b = band(sp.acc);
  return (
    <div className="subj-acc-card" style={{ borderColor:b.c+'66', background:b.soft }}>
      <button onClick={onToggle} style={{ all:'unset', cursor:'pointer', width:'100%', boxSizing:'border-box', display:'flex', alignItems:'center', gap:12, padding:'13px 14px' }}>
        <div style={{ minWidth:0 }}>
          <Ti t={sp.s} style={{ fontWeight:700, fontSize:14.5, display:'block' }}/>
          <span className="tiny" style={{ fontFamily:'var(--en)' }}>{sp.qs} <Ti hi="प्रश्न" en="Qs"/></span>
        </div>
        <div style={{ marginLeft:'auto', textAlign:'center', background:'#fff', borderRadius:10, padding:'6px 14px' }}>
          <div className="tiny" style={{ lineHeight:1 }}><Ti hi="सटीकता" en="Accuracy"/></div>
          <div style={{ fontWeight:800, fontSize:18, color:b.c, fontFamily:'var(--en)' }}>{sp.acc==null?'—':sp.acc+'%'}</div>
        </div>
        <i className={'fa-solid fa-chevron-'+(open?'up':'down')} style={{ color:b.c, fontSize:12 }}></i>
      </button>
      {open && (
        <div style={{ padding:'0 14px 14px' }}>
          <div style={{ display:'flex', gap:8 }}>
            {[
              { v:sp.correct, c:'var(--ok)', hi:'सही', en:'Correct' },
              { v:sp.incorrect, c:'var(--bad)', hi:'ग़लत', en:'Incorrect' },
              { v:sp.unatt, c:'var(--ink3)', hi:'अनुत्तरित', en:'Unattempted' },
            ].map((x,k)=>(
              <div key={k} style={{ flex:1, background:'#fff', borderRadius:10, padding:'9px 6px', textAlign:'center' }}>
                <div style={{ fontWeight:800, fontSize:17, fontFamily:'var(--en)', color:x.c }}>{x.v}</div>
                <div className="tiny" style={{ lineHeight:1.2 }}><Ti hi={x.hi} en={x.en}/></div>
              </div>
            ))}
          </div>
          <div className="row" style={{ gap:7, margin:'14px 0 10px' }}>
            <i className="fa-solid fa-layer-group" style={{ color:b.c, fontSize:12 }}></i>
            <span style={{ fontWeight:700, fontSize:13 }}><Ti hi="अध्याय-वार सटीकता" en="Chapter accuracy insights"/></span>
          </div>
          <div className="chap-grid">
            {sp.chapters.map((ch,k)=>{
              const cb = band(ch.acc);
              return (
                <div key={k} className="chap-cell" style={{ borderColor:cb.c+'55', background:'#fff' }}>
                  <div className="row" style={{ justifyContent:'space-between', alignItems:'flex-start', gap:6 }}>
                    <Ti t={ch.n} style={{ fontWeight:600, fontSize:12, lineHeight:1.3, display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical', overflow:'hidden' }}/>
                    <span style={{ fontWeight:800, fontSize:12.5, color:cb.c, fontFamily:'var(--en)', flexShrink:0 }}>{ch.acc==null?'—':ch.acc+'%'}</span>
                  </div>
                  <div className="tiny" style={{ marginTop:7 }}>
                    {ch.acc==null
                      ? <Ti hi="अभी नहीं पढ़ा" en="Not covered yet"/>
                      : <span><i className="fa-solid fa-check" style={{color:'var(--ok)',fontSize:9}}></i> {ch.correct} <Ti hi="सही" en="Correct"/> · {ch.att} <Ti hi="हल" en="Attempted"/></span>}
                  </div>
                  {ch.acc!=null && <span className="cbar" style={{ width:ch.acc+'%', background:cb.c }}/>}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

// ---------- generic line plotter (handles inverted metrics like rank/speed) ----------
function plotLine(data, W, H, pad, lo, hi, invert){
  const span = (hi-lo)||1;
  const x = i => pad + i*(W-2*pad)/(data.length-1);
  const y = v => { const t=(v-lo)/span; return 14 + (invert? t : (1-t))*(H-30); };
  return { x, y, path: data.map((v,i)=>`${i?'L':'M'}${x(i)},${y(v)}`).join(' ') };
}

// ---------- switchable metric trend (You vs Class) ----------
function MetricTrend(){
  const [mid,setMid] = useState('acc');
  const m = TRENDS.metrics.find(x=>x.id===mid);
  const W=300,H=132,pad=10;
  const all = [...m.data, ...(m.classData||[])];
  let lo=Math.min(...all), hi=Math.max(...all);
  const padv=(hi-lo)*0.18||1; lo-=padv; hi+=padv;
  const me = plotLine(m.data, W, H, pad, lo, hi, m.invert);
  const cls = m.classData ? plotLine(m.classData, W, H, pad, lo, hi, m.invert) : null;
  const first=m.data[0], last=m.data[m.data.length-1];
  const improved = m.good==='up' ? last>first : last<first;
  const deltaTxt = m.id==='rank' ? `${Math.abs(last-first)} ${''}` : (Math.round((last-first)*10)/10);
  return (
    <div className="card" style={{ padding:'14px 12px 10px' }}>
      <div style={{ display:'flex', gap:6, marginBottom:13, flexWrap:'wrap' }}>
        {TRENDS.metrics.map(x=>(
          <button key={x.id} onClick={()=>setMid(x.id)} style={{ cursor:'pointer', border:'1px solid '+(mid===x.id?x.color:'var(--line)'), background:mid===x.id?x.color:'#fff', color:mid===x.id?'#fff':'var(--ink2)', fontWeight:700, fontSize:11.5, padding:'6px 11px', borderRadius:100, fontFamily:'inherit' }}>
            <Ti t={x.label}/>
          </button>
        ))}
      </div>
      <div className="row" style={{ justifyContent:'space-between', alignItems:'flex-end', marginBottom:4, padding:'0 4px' }}>
        <div>
          <div className="tiny"><Ti hi="अभी" en="Now"/></div>
          <div style={{ fontWeight:800, fontSize:24, fontFamily:'var(--en)', color:m.color, lineHeight:1 }}>
            {m.id==='rank'?'#':''}{last}{m.unit}{m.of?<span style={{fontSize:13,color:'var(--ink3)'}}> / {m.of}</span>:null}
          </div>
        </div>
        <span style={{ fontSize:11.5, fontWeight:800, color:improved?'var(--ok)':'var(--bad)', background:improved?'var(--ok-soft)':'var(--bad-soft, #fbe8e6)', padding:'4px 9px', borderRadius:100 }}>
          <i className={'fa-solid '+(improved?'fa-arrow-trend-up':'fa-arrow-trend-down')}></i> {m.id==='rank'? (improved?'▲':'▼')+Math.abs(last-first) : (last>first?'+':'')+deltaTxt+m.unit}
        </span>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width:'100%', display:'block' }}>
        <defs><linearGradient id={'mg'+m.id} x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor={m.color} stopOpacity=".18"/><stop offset="1" stopColor={m.color} stopOpacity="0"/></linearGradient></defs>
        <path d={`${me.path} L${me.x(m.data.length-1)},${H-16} L${me.x(0)},${H-16} Z`} fill={`url(#mg${m.id})`}/>
        {cls && <path d={cls.path} fill="none" stroke="var(--ink3)" strokeWidth="1.6" strokeDasharray="4 4" strokeLinecap="round"/>}
        <path d={me.path} fill="none" stroke={m.color} strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round"/>
        {m.data.map((v,i)=>(
          <g key={i}>
            <circle cx={me.x(i)} cy={me.y(v)} r={i===m.data.length-1?5:3} fill="#fff" stroke={m.color} strokeWidth="2.4"/>
            <text x={me.x(i)} y={H-3} fontSize="9" fill="var(--ink3)" textAnchor="middle" fontFamily="var(--en)">{WK_LABELS[i]}</text>
          </g>
        ))}
      </svg>
      {cls && (
        <div className="row" style={{ gap:16, justifyContent:'center', marginTop:4 }}>
          <span className="tiny"><span style={{ display:'inline-block', width:14, height:3, background:m.color, borderRadius:2, verticalAlign:'middle' }}/> <Ti hi="तुम" en="You"/></span>
          <span className="tiny"><span style={{ display:'inline-block', width:14, height:0, borderTop:'2px dashed var(--ink3)', verticalAlign:'middle' }}/> <Ti hi="कक्षा औसत" en="Class avg"/></span>
        </div>
      )}
    </div>
  );
}

// ---------- subject mastery multi-line ----------
function SubjectTrendChart(){
  const W=300,H=140,pad=10, lo=45, hi=92;
  return (
    <div className="card" style={{ padding:'14px 12px 12px' }}>
      <svg viewBox={`0 0 ${W} ${H}`} style={{ width:'100%', display:'block' }}>
        {[50,70,90].map(g=>{ const yy=plotLine([g],W,H,pad,lo,hi,false).y(g); return <line key={g} x1={pad} x2={W-pad} y1={yy} y2={yy} stroke="var(--line2)" strokeDasharray="3 4"/>; })}
        {TRENDS.subjectLines.map(s=>{ const p=plotLine(s.data,W,H,pad,lo,hi,false); return (
          <g key={s.id}>
            <path d={p.path} fill="none" stroke={s.color} strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round"/>
            <circle cx={p.x(s.data.length-1)} cy={p.y(s.data[s.data.length-1])} r="4" fill={s.color}/>
          </g>
        ); })}
        {WK_LABELS.map((w,i)=>{ const xx=plotLine([0],W,H,pad,lo,hi,false).x; return <text key={w} x={pad+i*(W-2*pad)/(WK_LABELS.length-1)} y={H-3} fontSize="9" fill="var(--ink3)" textAnchor="middle" fontFamily="var(--en)">{w}</text>; })}
      </svg>
      <div style={{ display:'flex', flexWrap:'wrap', gap:'7px 16px', justifyContent:'center', marginTop:8 }}>
        {TRENDS.subjectLines.map(s=>(
          <span key={s.id} className="tiny"><span style={{ display:'inline-block', width:11, height:11, borderRadius:3, background:s.color, verticalAlign:'-1px' }}/> <Ti t={s.label}/></span>
        ))}
      </div>
    </div>
  );
}

// ---------- AINA insight card ----------
function InsightCard({ ins }){
  const good = ins.tone==='good';
  const c = good?'var(--ok)':'#9a6500';
  const bg = good?'var(--ok-soft)':'var(--warn-soft)';
  return (
    <div className="card" style={{ padding:'13px 14px', marginBottom:10, border:'none', background:'#fff', display:'flex', gap:12, boxShadow:'0 5px 18px -12px rgba(30,45,80,.22)' }}>
      <span style={{ width:38, height:38, borderRadius:11, background:bg, color:c, display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0 }}><i className={'fa-solid '+ins.icon}></i></span>
      <div style={{ flex:1, minWidth:0 }}>
        <T t={ins.title} tag="div" sec={false} style={{ fontWeight:700, fontSize:13.5 }}/>
        <T t={ins.body} tag="div" sec={false} style={{ fontSize:12.5, lineHeight:1.55, color:'var(--ink2)', marginTop:3 }}/>
      </div>
    </div>
  );
}

function ProgressScreen(){
  const { go } = useApp();
  const [term,setTerm] = useState(REPORT.terms[0]);
  const [termOpen,setTermOpen] = useState(false);
  const [open,setOpen] = useState('math');
  const r = REPORT;
  return (
    <div className="screen has-nav">
      <StatusBar light bg="var(--accent)"/>
      <Header color="var(--accent)" title={{hi:'प्रगति रिपोर्ट',en:'Progress Report'}} sub={{hi:'नीतू का संचयी प्रदर्शन',en:'Neetu’s cumulative performance'}}
        right={<button style={{ background:'rgba(255,255,255,.18)', border:'none', color:'#fff', width:34, height:34, borderRadius:11, cursor:'pointer' }}><i className="fa-solid fa-download"></i></button>}/>

      <div className="body" style={{ marginTop:-14 }}>
        {/* term selector */}
        <div className="px">
          <button onClick={()=>setTermOpen(o=>!o)} className="card" style={{ width:'100%', padding:'13px 15px', display:'flex', alignItems:'center', justifyContent:'space-between', cursor:'pointer', boxShadow:'0 6px 20px -12px rgba(30,45,80,.25)' }}>
            <Ti t={term} style={{ fontWeight:700, fontSize:14 }}/>
            <i className={'fa-solid fa-chevron-'+(termOpen?'up':'down')} style={{ color:'var(--ink3)', fontSize:12 }}></i>
          </button>
          {termOpen && (
            <div className="card" style={{ marginTop:6, overflow:'hidden' }}>
              {r.terms.map((tm,i)=>(
                <button key={tm.id} onClick={()=>{ setTerm(tm); setTermOpen(false); }} style={{ all:'unset', cursor:'pointer', display:'block', width:'100%', boxSizing:'border-box', padding:'12px 15px', borderBottom:i<r.terms.length-1?'1px solid var(--line2)':'none', background:term.id===tm.id?'var(--accent-soft)':'#fff' }}>
                  <Ti t={tm} style={{ fontSize:13.5, fontWeight: term.id===tm.id?700:500, color: term.id===tm.id?'var(--accent-ink)':'var(--ink)' }}/>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* headline stats */}
        <div className="px" style={{ marginTop:18 }}>
          <T hi="मुख्य आँकड़े" en="Highlights" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5, marginBottom:11 }}/>
          <div className="card shadow-card" style={{ padding:16 }}>
            <div className="row" style={{ gap:16 }}>
              <Ring pct={r.avg.pct} size={92} stroke={10} color="var(--ok)">
                <div style={{ fontWeight:800, fontSize:18, fontFamily:'var(--en)' }}>{r.avg.pct}%</div>
              </Ring>
              <div style={{ flex:1 }}>
                <div className="tiny"><Ti hi="औसत स्कोर" en="Average score"/></div>
                <div style={{ fontWeight:800, fontSize:30, fontFamily:'var(--en)', lineHeight:1.05 }}>{r.avg.score}<span style={{ fontSize:16, color:'var(--ink3)' }}> / {r.avg.max}</span></div>
                <div className="tiny" style={{ marginTop:3 }}><Ti hi="कक्षा औसत" en="Class average"/>: {r.avg.classAvg} / {r.avg.max}</div>
              </div>
            </div>
            <div style={{ display:'flex', gap:9, marginTop:14 }}>
              <div style={{ flex:1, background:'var(--bg)', borderRadius:12, padding:'11px 12px' }}>
                <div className="row" style={{ justifyContent:'space-between' }}>
                  <span className="tiny"><Ti hi="सटीकता" en="Accuracy"/></span>
                  <span style={{ fontWeight:800, fontSize:18, color:'var(--ok)', fontFamily:'var(--en)' }}>{r.accuracy.pct}%</span>
                </div>
                <div className="tiny" style={{ marginTop:2 }}><Ti hi="कक्षा" en="Class"/>: {r.accuracy.classPct}%</div>
              </div>
              <div style={{ flex:1, background:'var(--bg)', borderRadius:12, padding:'11px 12px' }}>
                <div className="row" style={{ justifyContent:'space-between' }}>
                  <span className="tiny"><Ti hi="टेस्ट दिए" en="Tests taken"/></span>
                  <span style={{ fontWeight:800, fontSize:18, color:'var(--accent)', fontFamily:'var(--en)' }}>{r.attempted.done}<span style={{fontSize:12, color:'var(--ink3)'}}>/{r.attempted.total}</span></span>
                </div>
                <div className="tiny" style={{ marginTop:2 }}><Ti hi="कक्षा रैंक" en="Class rank"/>: {r.rank.pos}/{r.rank.of} <span style={{color:'var(--ok)', fontWeight:700}}>▲{r.rank.delta}</span></div>
              </div>
            </div>
          </div>
        </div>

        {/* recent tests carousel */}
        <div className="px row" style={{ justifyContent:'space-between', marginTop:22, marginBottom:11 }}>
          <T hi="हाल के टेस्ट" en="Recent Tests" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
          <button className="tiny" style={{ background:'none', border:'none', color:'var(--accent)', fontWeight:700 }} onClick={()=>go('tests')}><Ti hi="सभी टेस्ट" en="View all tests"/></button>
        </div>
        <RecentTestsDeck/>

        {/* trends over time */}
        <div className="px" style={{ marginTop:24 }}>
          <div className="row" style={{ justifyContent:'space-between', marginBottom:3 }}>
            <T hi="समय के साथ प्रवृत्तियाँ" en="Trends Over Time" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
            <span style={{ fontSize:11, fontWeight:800, color:'var(--ok)', background:'var(--ok-soft)', padding:'4px 9px', borderRadius:100 }}><i className="fa-solid fa-arrow-trend-up"></i> +21%</span>
          </div>
          <div className="tiny" style={{ marginBottom:11 }}><Ti hi="पिछले 6 साप्ताहिक मूल्यांकनों के आधार पर" en="Based on the last 6 weekly assessments"/></div>
          <MetricTrend/>
          <div className="tiny" style={{ marginTop:7, textAlign:'center' }}><Ti hi="मीट्रिक बदलने के लिए ऊपर टैप करें" en="Tap a metric above to switch the trend"/></div>
        </div>

        {/* subject mastery trend */}
        <div className="px" style={{ marginTop:22 }}>
          <T hi="विषय निपुणता प्रवृत्ति" en="Subject Mastery Trend" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5, marginBottom:3 }}/>
          <div className="tiny" style={{ marginBottom:11 }}><Ti hi="हर विषय में निपुणता % — सप्ताह दर सप्ताह" en="Mastery % per subject, week over week"/></div>
          <SubjectTrendChart/>
        </div>

        {/* AINA insights from trends */}
        <div className="px" style={{ marginTop:24 }}>
          <div className="row" style={{ gap:9, marginBottom:12 }}>
            <Mascot size={28}/>
            <div>
              <T hi="आइना की समझ" en="AINA’s Insights" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5, lineHeight:1.1 }}/>
              <div className="tiny"><Ti hi="तुम्हारी प्रवृत्तियों से निकाले गए सुझाव" en="What your trends are telling us"/></div>
            </div>
          </div>
          {TREND_INSIGHTS.map((ins,i)=><InsightCard key={i} ins={ins}/>)}
        </div>

        {/* subject-wise performance */}
        <div className="px" style={{ marginTop:24 }}>
          <T hi="विषय-वार प्रदर्शन" en="Subject-wise Performance" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
          <div className="card" style={{ padding:14, margin:'11px 0 14px' }}>
            <div className="tiny" style={{ fontWeight:700, marginBottom:9 }}><Ti hi="सटीकता प्रतिशत के आधार पर" en="Based on accuracy percentage"/></div>
            <div className="band-legend">
              {[band(90),band(70),band(50),band(20),band(null)].map((b,i)=>(
                <div key={i} className="row" style={{ gap:9 }}>
                  <span className="band-dot" style={{ background:b.c }}/>
                  <span className="tiny" style={{ color:'var(--ink2)' }}><Ti t={b.l}/></span>
                </div>
              ))}
            </div>
          </div>
          {SUBJECT_PERF.map(sp=>(
            <SubjectPerfCard key={sp.id} sp={sp} open={open===sp.id} onToggle={()=>setOpen(o=>o===sp.id?null:sp.id)}/>
          ))}
        </div>

        {/* competency heatmap */}
        <div className="px" style={{ marginTop:14 }}>
          <T hi="दक्षता हीटमैप" en="Competency Heatmap" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
          <div className="tiny" style={{ margin:'4px 0 11px' }}><Ti hi="हर कोशिका = उस सप्ताह की निपुणता" en="Each cell = mastery that week"/></div>
          <div className="card" style={{ padding:14 }}>
            <div style={{ display:'grid', gridTemplateColumns:'42px repeat(6,1fr)', gap:5, alignItems:'center' }}>
              <span/>
              {TREND.map(t=><span key={t.w} className="tiny" style={{ textAlign:'center', fontFamily:'var(--en)' }}>{t.w.replace('W','')}</span>)}
              {HEAT.map((row,ri)=>(
                <React.Fragment key={ri}>
                  <span className="tiny" style={{ fontWeight:700, color:'var(--ink2)' }}><Ti t={row.s}/></span>
                  {row.c.map((v,ci)=>(<div key={ci} className="hm" title={v+'%'} style={{ background:heatColor(v) }}/>))}
                </React.Fragment>
              ))}
            </div>
            <div className="row" style={{ gap:6, marginTop:13, justifyContent:'flex-end', alignItems:'center' }}>
              <span className="tiny"><Ti hi="कम" en="Low"/></span>
              {[50,60,70,80,90].map(v=><span key={v} style={{ width:14, height:14, borderRadius:4, background:heatColor(v) }}/>)}
              <span className="tiny"><Ti hi="अधिक" en="High"/></span>
            </div>
          </div>
        </div>

        {/* streak */}
        <div className="px" style={{ marginTop:24 }}>
          <div className="row" style={{ justifyContent:'space-between', marginBottom:12 }}>
            <T hi="अभ्यास की लय" en="Practice Streak" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
            <span className="chip" style={{ background:'var(--warn-soft)', color:'#9a6500' }}><i className="fa-solid fa-fire" style={{color:'#e8862b'}}></i> <Ti hi="12 दिन" en="12 days"/></span>
          </div>
          <div className="card" style={{ padding:14 }}>
            <div style={{ display:'grid', gridTemplateColumns:'repeat(7,1fr)', gap:7 }}>
              {['S','M','T','W','T','F','S'].map((d,i)=><span key={i} className="tiny" style={{ textAlign:'center', fontFamily:'var(--en)' }}>{d}</span>)}
              {STREAK_DAYS.map((on,i)=>(
                <div key={i} style={{ aspectRatio:1, borderRadius:8, display:'flex', alignItems:'center', justifyContent:'center', background:on?'var(--ok-soft)':'var(--bg)', color:on?'var(--ok)':'var(--line)', fontSize:12 }}>
                  {on? <i className="fa-solid fa-fire"></i> : <i className="fa-solid fa-minus" style={{fontSize:8}}></i>}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* strengths & focus */}
        <div className="px" style={{ marginTop:24 }}>
          <T hi="ताक़त और सुधार" en="Strengths & Focus" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5, marginBottom:12 }}/>
          <div className="row" style={{ gap:11, alignItems:'stretch' }}>
            <div className="card" style={{ flex:1, padding:13, borderTop:'3px solid var(--ok)' }}>
              <i className="fa-solid fa-trophy" style={{ color:'var(--ok)' }}></i>
              <div style={{ fontWeight:700, fontSize:12.5, marginTop:7 }}><Ti hi="मज़बूत" en="Strengths"/></div>
              <div className="tiny" style={{ marginTop:5, lineHeight:1.5 }}><Ti hi="हिंदी, आँकड़ों का प्रबंधन, पादप पोषण" en="Hindi, Data handling, Plant nutrition"/></div>
            </div>
            <div className="card" style={{ flex:1, padding:13, borderTop:'3px solid var(--bad)' }}>
              <i className="fa-solid fa-bullseye" style={{ color:'var(--bad)' }}></i>
              <div style={{ fontWeight:700, fontSize:12.5, marginTop:7 }}><Ti hi="ध्यान दें" en="Focus on"/></div>
              <div className="tiny" style={{ marginTop:5, lineHeight:1.5 }}><Ti hi="परिमेय संख्याएँ, जल, तर्क समझाना" en="Rational numbers, Water, Explaining reasoning"/></div>
            </div>
          </div>
          <button className="btn btn-magenta" style={{ marginTop:14 }} onClick={()=>go('mentor')}><Mascot size={26}/> <Ti hi="आइना के साथ कमज़ोरी पर काम करें" en="Work on gaps with AINA"/></button>
        </div>
      </div>
      <BottomNav/>
    </div>
  );
}

Object.assign(window, { ProgressScreen });
