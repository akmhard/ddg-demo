// screen-results.jsx
function levelColor(l){ return l==='strong'?'var(--ok)':l==='good'?'var(--accent)':'var(--bad)'; }
function levelLabel(l){ return l==='strong'?{hi:'मज़बूत',en:'Strong'}:l==='good'?{hi:'ठीक',en:'On track'}:{hi:'कमज़ोर',en:'Needs work'}; }

function ResultsScreen(){
  const { go, play, mode } = useApp();
  const ess = mode==='essential';
  const r = RESULT;
  const pct = Math.round(r.score/r.max*100);
  return (
    <div className="screen has-nav">
      <StatusBar light bg="#1b8a4b"/>
      {/* celebratory header */}
      <div style={{ background:'linear-gradient(160deg,#1b8a4b,#1E9E54 55%,#39b76b)', color:'#fff', padding:'2px 18px 26px', position:'relative', overflow:'hidden' }}>
        {play!=='official' && <Confetti n={play==='playful'?40:24}/>}
        <div className="row" style={{ justifyContent:'space-between', minHeight:34, position:'relative', zIndex:5 }}>
          <button onClick={()=>go('home')} style={{ background:'rgba(255,255,255,.18)', border:'none', color:'#fff', width:34, height:34, borderRadius:11, cursor:'pointer' }}><i className="fa-solid fa-house"></i></button>
          <span style={{ fontWeight:600, fontSize:13, paddingTop:9, opacity:.9 }}><Ti hi="सप्ताह 14 · गणित" en="Week 14 · Maths"/></span>
          <button style={{ background:'rgba(255,255,255,.18)', border:'none', color:'#fff', width:34, height:34, borderRadius:11, cursor:'pointer' }}><i className="fa-solid fa-share-nodes"></i></button>
        </div>
        <div style={{ textAlign:'center', marginTop:6, position:'relative', zIndex:5 }}>
          <div className="pop" style={{ display:'inline-block' }}>
            <Ring pct={pct} size={132} stroke={12} color="#fff" track="rgba(255,255,255,.28)">
              <div style={{ fontWeight:800, fontSize:30, fontFamily:'var(--en)' }}>{r.score}<span style={{ fontSize:16, opacity:.8 }}>/{r.max}</span></div>
              <div style={{ fontSize:11, opacity:.9, fontWeight:600 }}>{pct}%</div>
            </Ring>
          </div>
          <T hi="शाबाश, नीतू!" en="Well done, Neetu!" tag="div" sec={false} style={{ fontWeight:800, fontSize:21, marginTop:10 }}/>
          <div style={{ fontSize:13, opacity:.92, marginTop:3 }}>{ess ? <Ti hi="6 में से 4 प्रश्न सही — अच्छी प्रगति" en="4 of 6 questions correct — good progress"/> : <Ti hi="पिछले हफ़्ते से 9% बेहतर — +50 XP अर्जित" en="9% better than last week — earned +50 XP"/>}</div>
        </div>
      </div>

      <div className="body" style={{ marginTop:-14 }}>
        {/* quick breakdown */}
        <div className="px">
          <div className="card shadow-card" style={{ padding:'15px 13px', display:'flex' }}>
            {[
              { big:r.correctMcq+'/'+r.totalMcq, c:'var(--ok)', ic:'fa-circle-check', hi:'सही MCQ', en:'MCQ correct' },
              { big:'2', c:'var(--magenta)', ic:'fa-pen-fancy', hi:'AI-जाँचे उत्तर', en:'AI-graded' },
              { big:r.time.en, c:'var(--accent)', ic:'fa-clock', hi:'समय लिया', en:'Time taken' },
            ].map((x,k)=>(
              <div key={k} style={{ flex:1, textAlign:'center', borderRight:k<2?'1px solid var(--line2)':'none' }}>
                <i className={'fa-solid '+x.ic} style={{ color:x.c, fontSize:15 }}></i>
                <div style={{ fontWeight:800, fontSize:16, marginTop:4, fontFamily:'var(--en)' }}>{x.big}</div>
                <div className="tiny" style={{ lineHeight:1.2 }}><Ti hi={x.hi} en={x.en}/></div>
              </div>
            ))}
          </div>
        </div>

        {/* competency mastery */}
        {!ess && (
        <div className="px" style={{ marginTop:22 }}>
          <div className="row" style={{ gap:8, marginBottom:12 }}>
            <i className="fa-solid fa-diagram-project" style={{ color:'var(--accent)' }}></i>
            <T hi="NCERT दक्षता मानचित्रण" en="NCERT Competency Mapping" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
          </div>
          <div className="card" style={{ padding:'4px 14px' }}>
            {r.competencies.map((c,k)=>(
              <div key={k} style={{ padding:'12px 0', borderBottom:k<r.competencies.length-1?'1px solid var(--line2)':'none' }}>
                <div className="row" style={{ justifyContent:'space-between', marginBottom:7 }}>
                  <div className="row" style={{ gap:8, minWidth:0 }}>
                    <span style={{ fontSize:10.5, fontWeight:800, color:'var(--ink2)', background:'var(--bg)', padding:'3px 6px', borderRadius:6, fontFamily:'var(--en)', flexShrink:0 }}>{c.code}</span>
                    <Ti t={{hi:c.hi,en:c.en}} style={{ fontSize:13, fontWeight:600 }}/>
                  </div>
                  <span style={{ fontSize:11, fontWeight:800, color:levelColor(c.level), flexShrink:0, marginLeft:6 }}>{c.pct}%</span>
                </div>
                <Bar pct={c.pct} color={levelColor(c.level)} h={7} delay={k*90}/>
              </div>
            ))}
          </div>
        </div>
        )}

        {/* learning gaps */}
        <div className="px" style={{ marginTop:22 }}>
          <div className="row" style={{ gap:8, marginBottom:12 }}>
            <i className="fa-solid fa-magnifying-glass-chart" style={{ color:'var(--bad)' }}></i>
            <T hi="पहचानी गई सीखने की कमियाँ" en="Learning Gaps Identified" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
          </div>
          {r.gaps.map((g,k)=>(
            <div key={k} className="card" style={{ padding:14, marginBottom:11, borderLeft:'3px solid var(--bad)' }}>
              <T t={{hi:g.hi,en:g.en}} tag="div" sec={false} style={{ fontWeight:700, fontSize:14 }}/>
              <div className="muted" style={{ fontSize:12.5, marginTop:5, lineHeight:1.5 }}><Ti t={g.note}/></div>
              <div className="row" style={{ gap:9, marginTop:12 }}>
                <button className="btn btn-primary" style={{ width:'auto', flex:1, padding:'11px', fontSize:13.5 }} onClick={()=>go('mentor')}><i className="fa-solid fa-wand-magic-sparkles"></i> <Ti hi="आइना से सीखें" en="Learn with AINA"/></button>
                <span className="chip" style={{ background:'var(--bg)', color:'var(--ink2)' }}><i className="fa-regular fa-clock"></i> {g.mins}m</span>
              </div>
            </div>
          ))}
        </div>

        {/* per-question AI review */}
        <div className="px" style={{ marginTop:22 }}>
          <div className="row" style={{ gap:8, marginBottom:12 }}>
            <i className="fa-solid fa-list-check" style={{ color:'var(--magenta)' }}></i>
            <T hi="प्रश्नवार समीक्षा" en="Question-by-Question Review" tag="div" sec={false} style={{ fontWeight:700, fontSize:15.5 }}/>
          </div>
          {r.perQ.map((p,k)=> <QReview key={k} p={p}/> )}
        </div>

        <div className="px" style={{ marginTop:20 }}>
          <button className="btn btn-magenta" onClick={()=>go('mentor')}><Mascot size={26}/> <Ti hi="आइना से पूरी समीक्षा कराएँ" en="Discuss results with AINA"/></button>
          <button className="btn btn-ghost" style={{ marginTop:11 }} onClick={()=>go('progress')}><i className="fa-solid fa-chart-line" style={{color:'var(--accent)'}}></i> <Ti hi="मेरी प्रगति देखें" en="View my progress"/></button>
        </div>
      </div>
      <BottomNav/>
    </div>
  );
}

function QReview({ p }){
  const [open,setOpen] = useState(false);
  const q = QUESTIONS[p.n-1];
  const subjective = q.type==='subjective';
  const stColor = p.ok===true?'var(--ok)':p.ok==='partial'?'var(--warn)':'var(--bad)';
  const stIcon = p.ok===true?'fa-check':p.ok==='partial'?'fa-circle-half-stroke':'fa-xmark';
  return (
    <div className="card" style={{ marginBottom:9, overflow:'hidden' }}>
      <button onClick={()=>setOpen(o=>!o)} style={{ all:'unset', cursor:'pointer', width:'100%', boxSizing:'border-box', padding:'12px 13px', display:'flex', alignItems:'center', gap:11 }}>
        <span style={{ width:28, height:28, borderRadius:9, background:stColor+'1f', color:stColor, display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, flexShrink:0 }}><i className={'fa-solid '+stIcon}></i></span>
        <div style={{ flex:1, minWidth:0 }}>
          <div className="row" style={{ gap:7 }}>
            <span style={{ fontWeight:700, fontSize:13 }}><Ti hi={'प्रश्न '+p.n} en={'Q'+p.n}/></span>
            {subjective && <span style={{ fontSize:9.5, fontWeight:700, color:'var(--magenta)', background:'#f6f4fd', padding:'2px 6px', borderRadius:5 }}><Ti hi="AI जाँचा" en="AI graded"/></span>}
          </div>
          <Ti t={q.q} className="muted" style={{ fontSize:11.5, display:'block', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}/>
        </div>
        <span style={{ fontWeight:800, fontSize:13, color:stColor, fontFamily:'var(--en)', flexShrink:0 }}>{p.mark}</span>
        <i className={'fa-solid fa-chevron-'+(open?'up':'down')} style={{ color:'var(--ink3)', fontSize:11 }}></i>
      </button>
      {open && (
        <div style={{ padding:'0 13px 14px', borderTop:'1px solid var(--line2)' }}>
          <T t={q.q} tag="div" style={{ fontSize:13.5, fontWeight:600, marginTop:11, lineHeight:1.45 }}/>
          {subjective ? (
            <div style={{ marginTop:11 }}>
              <div className="tiny" style={{ fontWeight:700, color:'var(--ink2)', marginBottom:4 }}><Ti hi="आपका उत्तर" en="Your answer"/></div>
              <div style={{ background:'var(--bg)', borderRadius:10, padding:'10px 12px', fontSize:13 }}>{p.yours? <Ti t={p.yours}/> : '—'}</div>
              <div className="card" style={{ marginTop:10, padding:'11px 12px', background:'#f6f4fd', border:'none', display:'flex', gap:9 }}>
                <Mascot size={26}/>
                <div>
                  <div className="tiny" style={{ fontWeight:700, color:'var(--magenta)', marginBottom:3 }}><Ti hi="आइना की प्रतिक्रिया" en="AINA's feedback"/></div>
                  <Ti t={p.ai} style={{ fontSize:12.8, lineHeight:1.55 }}/>
                </div>
              </div>
            </div>
          ) : (
            <div style={{ display:'flex', flexDirection:'column', gap:8, marginTop:11 }}>
              {q.opts.map((o,k)=>{
                const isCorrect = k===q.correct, isChosen = k===p.chose;
                const cls = isCorrect?'opt correct':(isChosen&&!p.ok?'opt wrong':'opt');
                return (
                  <div key={k} className={cls} style={{ padding:'10px 12px' }}>
                    <span className="key" style={{ width:26, height:26, fontSize:12 }}>{o.k}</span>
                    <Ti t={{hi:o.hi,en:o.en}} style={{ fontWeight:600, fontSize:13.5, flex:1 }}/>
                    {isCorrect && <i className="fa-solid fa-check" style={{ color:'var(--ok)' }}></i>}
                    {isChosen && !p.ok && <i className="fa-solid fa-xmark" style={{ color:'var(--bad)' }}></i>}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
Object.assign(window, { ResultsScreen });
