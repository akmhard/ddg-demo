// screen-splash.jsx — official launch / welcome screen
function SplashScreen(){
  const { go, lang, setLang, openPrefs } = useApp();
  const cycle = ()=> setLang(lang==='bi'?'hi':lang==='hi'?'en':'bi');
  const langLabel = lang==='bi'?'हिं · EN':lang==='hi'?'हिंदी':'ENG';
  return (
    <div className="screen">
      <StatusBar dark/>
      <div className="body" style={{ paddingBottom:0, display:'flex', flexDirection:'column', background:'#fff' }}>
        {/* govt identity bar */}
        <div className="px row" style={{ justifyContent:'space-between', alignItems:'center', paddingTop:2, paddingBottom:12 }}>
          <div className="row" style={{ gap:10 }}>
            <img src={window.__resources.emblem} alt="State Emblem of India" style={{ height:38 }}/>
            <div style={{ borderLeft:'1px solid var(--line)', paddingLeft:10, lineHeight:1.3 }}>
              <div style={{ fontSize:11, fontWeight:700, color:'var(--ink)' }}><Ti hi="दिल्ली सरकार" en="Govt. of NCT of Delhi"/></div>
              <div style={{ fontSize:9.5, color:'var(--ink2)' }}><Ti hi="शिक्षा निदेशालय" en="Directorate of Education"/></div>
            </div>
          </div>
          <div className="row" style={{ gap:8 }}>
            <button onClick={cycle} className="row" style={{ gap:6, whiteSpace:'nowrap', background:'var(--accent-soft)', border:'1px solid var(--accent-soft)', color:'var(--accent-ink)', borderRadius:8, padding:'7px 11px', fontSize:11.5, fontWeight:700, cursor:'pointer', fontFamily:'var(--en)' }}>
              <i className="fa-solid fa-globe" style={{fontSize:12}}></i>{langLabel}
            </button>
            <button onClick={openPrefs} aria-label="Preferences" style={{ width:34, height:34, borderRadius:8, background:'var(--accent-soft)', border:'1px solid var(--accent-soft)', color:'var(--accent-ink)', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center' }}>
              <i className="fa-solid fa-sliders" style={{fontSize:13}}></i>
            </button>
          </div>
        </div>

        {/* tricolour accent rule */}
        <div className="row" style={{ height:3 }}>
          <span style={{ flex:1, background:'#FF9933' }}/><span style={{ flex:1, background:'#fff', borderTop:'1px solid var(--line2)', borderBottom:'1px solid var(--line2)' }}/><span style={{ flex:1, background:'#138808' }}/>
        </div>

        {/* launch banner */}
        <div style={{ textAlign:'center', padding:'18px 22px 2px' }}>
          <span className="chip" style={{ background:'var(--magenta-50,#f6f4fd)', color:'var(--magenta)' }}><i className="fa-solid fa-rocket" style={{fontSize:11}}></i> <Ti hi="एक नई पहल" en="A new initiative"/></span>
          <div className="hi" style={{ fontSize:23, fontWeight:700, marginTop:13, lineHeight:1.25, color:'var(--ink)' }}>{lang==='en'?'Shiksha Saarthi':'शिक्षा सारथी'}</div>
          <div style={{ fontSize:12.5, color:'var(--ink2)', marginTop:5, lineHeight:1.5, maxWidth:300, margin:'5px auto 0' }}>
            <Ti hi="दिल्ली के हर सरकारी स्कूल के विद्यार्थी के लिए — AI आधारित साप्ताहिक मूल्यांकन एवं मार्गदर्शन।" en="AI-powered weekly assessment & mentoring for every Delhi Govt school student."/>
          </div>
        </div>

        {/* hero promotional image */}
        <div style={{ position:'relative', padding:'4px 8px 0', marginTop:4 }}>
          <img src={window.__resources.launch} alt="" style={{ width:'100%', display:'block' }}/>
        </div>

        {/* dignitary attribution */}
        <div className="px" style={{ marginTop:-6, paddingBottom:6 }}>
          <div className="card" style={{ padding:'13px 15px', display:'flex', alignItems:'center', gap:12, borderLeft:'3px solid var(--accent)' }}>
            <div style={{ flex:1 }}>
              <div className="tiny" style={{ fontWeight:600, color:'var(--ink3)' }}><Ti hi="माननीय मुख्यमंत्री द्वारा प्रारंभ" en="Launched by the Hon'ble Chief Minister"/></div>
              <div style={{ fontWeight:700, fontSize:14.5, marginTop:2, color:'var(--ink)' }}><Ti hi="श्रीमती रेखा गुप्ता" en="Smt. Rekha Gupta"/></div>
              <div className="tiny" style={{ marginTop:1 }}><Ti hi="मुख्यमंत्री, दिल्ली सरकार" en="Chief Minister, Govt. of NCT of Delhi"/></div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA footer */}
      <div style={{ padding:'12px 22px 18px', background:'#fff', borderTop:'1px solid var(--line)' }}>
        <button className="btn btn-primary" onClick={()=>go('login')}>
          <Ti hi="आरंभ करें" en="Get Started"/><i className="fa-solid fa-arrow-right" style={{fontSize:13}}></i>
        </button>
        <div style={{ marginTop:13 }}>
          <PoweredBy/>
        </div>
      </div>
    </div>
  );
}
Object.assign(window, { SplashScreen });
