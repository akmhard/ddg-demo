// ui.jsx — shared primitives
const { useState, useEffect, useRef } = React;

// ---------- bilingual text ----------
function T({ hi, en, t, tag='span', sec=true, className='', style }){
  const { lang } = useApp();
  t = t || { hi, en };
  const Tag = tag;
  if(lang==='en') return <Tag className={className} style={style}>{t.en}</Tag>;
  if(lang==='hi') return <Tag className={'hi '+className} style={style}>{t.hi}</Tag>;
  return (
    <Tag className={className} style={{ ...style, lineHeight:1.18 }}>
      <span className="hi" style={{ display:'block' }}>{t.hi}</span>
      {sec && <span style={{ display:'block', fontSize:'.72em', opacity:.6, fontWeight:400, fontFamily:'var(--en)', marginTop:1 }}>{t.en}</span>}
    </Tag>
  );
}
// inline single-line (primary only when bilingual)
function Ti({ hi, en, t, className='', style }){
  const { lang } = useApp();
  t = t || { hi, en };
  const txt = lang==='en' ? t.en : t.hi;
  return <span className={(lang==='en'?'':'hi ')+className} style={style}>{txt}</span>;
}

// ---------- status bar ----------
function StatusBar({ light=false, bg='transparent' }){
  return (
    <div className={'statusbar '+(light?'light':'dark')} style={{ background:bg }}>
      <span className="sb-time">9:30</span>
      <span className="sb-ic">
        <i className="fa-solid fa-signal" style={{fontSize:12}}></i>
        <i className="fa-solid fa-wifi" style={{fontSize:12}}></i>
        <i className="fa-solid fa-battery-three-quarters" style={{fontSize:14}}></i>
      </span>
    </div>
  );
}

// ---------- AINA avatar ----------
function Mascot({ size=44, mood='happy', ring=false }){
  return (
    <span className="mascot" style={{ width:size, height:size, flexShrink:0 }}>
      <img src={window.__resources.aina} alt="AINA" draggable="false"
        style={{ width:'100%', height:'100%', borderRadius:'50%', objectFit:'cover', display:'block',
          boxShadow: ring?'0 0 0 2px rgba(255,255,255,.85)':'none' }}/>
    </span>
  );
}

// ---------- ring (donut progress) ----------
function Ring({ pct=0, size=120, stroke=11, color='var(--accent)', track='var(--line2)', children }){
  const r = (size-stroke)/2, c = 2*Math.PI*r;
  const [v,setV] = useState(0);
  useEffect(()=>{ const id=setTimeout(()=>setV(pct),60); return ()=>clearTimeout(id); },[pct]);
  return (
    <div style={{ position:'relative', width:size, height:size }}>
      <svg width={size} height={size} style={{ transform:'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} stroke={track} strokeWidth={stroke} fill="none"/>
        <circle cx={size/2} cy={size/2} r={r} stroke={color} strokeWidth={stroke} fill="none"
          strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c-(c*v/100)}
          style={{ transition:'stroke-dashoffset 1s cubic-bezier(.2,.8,.2,1)' }}/>
      </svg>
      <div style={{ position:'absolute', inset:0, display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center' }}>
        {children}
      </div>
    </div>
  );
}

// ---------- progress bar ----------
function Bar({ pct, color='var(--accent)', h=8, delay=0 }){
  const [v,setV] = useState(0);
  useEffect(()=>{ const id=setTimeout(()=>setV(pct),60+delay); return ()=>clearTimeout(id); },[pct,delay]);
  return <div className="bar" style={{height:h}}><i style={{ width:v+'%', background:color }}></i></div>;
}

// ---------- confetti burst ----------
function Confetti({ n=26 }){
  const cols=['#1A73E9','#a066cc','#1E9E54','#F0A202','#E0524A','#2D6BE3'];
  return (
    <div style={{ position:'absolute', inset:0, overflow:'hidden', pointerEvents:'none', zIndex:30 }}>
      {Array.from({length:n}).map((_,i)=>(
        <span key={i} className="confetti" style={{
          left:(5+Math.random()*90)+'%', background:cols[i%cols.length],
          animation:`fall ${1.3+Math.random()*1.1}s ${Math.random()*.5}s ease-in forwards`,
          transform:`rotate(${Math.random()*360}deg)`
        }}/>
      ))}
    </div>
  );
}

// ---------- bottom nav ----------
function BottomNav(){
  const { screen, go, mode } = useApp();
  const items = [
    { id:'home', icon:'fa-house', hi:'होम', en:'Home' },
    { id:'tests', icon:'fa-clipboard-list', hi:'टेस्ट', en:'Tests' },
    { id:'mentor', center:true, icon:'fa-wand-magic-sparkles', hi:'आइना', en:'AINA' },
    { id:'progress', icon:'fa-chart-line', hi:'प्रगति', en:'Progress' },
    { id:'profile', icon:'fa-user', hi:'प्रोफ़ाइल', en:'Profile' },
  ].filter(it => !(mode==='essential' && it.id==='progress'));
  const active = (id) => screen===id || (id==='tests' && ['tests','assessIntro','assessQ','results'].includes(screen));
  const onMentor = screen==='mentor';
  return (
    <nav className="botnav">
      {items.map(it => (it.center && !onMentor) ? (
        <button key={it.id} className="nav-i nav-center" onClick={()=>go('mentor')}>
          <span className="fab"><img src={window.__resources.aina} alt="AINA" draggable="false" style={{ width:'100%', height:'100%', borderRadius:'50%', objectFit:'cover' }}/></span>
          <span style={{marginTop:30, color:'var(--ink3)'}}><Ti hi={it.hi} en={it.en}/></span>
        </button>
      ) : (
        <button key={it.id} className={'nav-i'+(active(it.id)||(it.center&&onMentor)?' active':'')} onClick={()=>go(it.center?'mentor':it.id)}
          style={it.center&&onMentor?{color:'var(--magenta)'}:undefined}>
          <i className={'fa-solid '+it.icon}></i>
          <span><Ti hi={it.hi} en={it.en}/></span>
        </button>
      ))}
    </nav>
  );
}

// ---------- screen header (colored) ----------
function Header({ title, sub, color, onBack, right }){
  return (
    <div style={{ background:color, padding:'4px 18px 20px', color:'#fff', position:'relative' }}>
      <div className="row" style={{ justifyContent:'space-between', minHeight:34 }}>
        {onBack
          ? <button onClick={onBack} style={{ background:'rgba(255,255,255,.18)', border:'none', color:'#fff', width:34, height:34, borderRadius:11, fontSize:15, cursor:'pointer' }}><i className="fa-solid fa-arrow-left"></i></button>
          : <span style={{width:34}}/>}
        {right || <span style={{width:34}}/>}
      </div>
      {title && <div style={{ marginTop:8 }}>
        <T t={title} tag="div" style={{ fontSize:21, fontWeight:700 }}/>
        {sub && <div style={{ opacity:.85, fontSize:13, marginTop:3 }}><Ti t={sub}/></div>}
      </div>}
    </div>
  );
}

// ---------- Powered by Infinity Learn ----------
function PoweredBy({ light=false }){
  // white logo → always sits on a dark pill so it reads on any background
  return (
    <div className="row" style={{ justifyContent:'center' }}>
      <span className="row" style={{ gap:9, background:'#101a33', borderRadius:100, padding:'7px 14px 7px 13px' }}>
        <span style={{ fontSize:10.5, fontWeight:600, color:'rgba(255,255,255,.7)', fontFamily:'var(--en)' }}>Powered by</span>
        <img src={window.__resources.il} alt="Infinity Learn" style={{ height:16, display:'block' }}/>
      </span>
    </div>
  );
}

Object.assign(window, { T, Ti, StatusBar, Mascot, Ring, Bar, Confetti, BottomNav, Header, PoweredBy });
